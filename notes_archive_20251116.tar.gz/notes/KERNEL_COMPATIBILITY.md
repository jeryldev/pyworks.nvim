# Kernel Compatibility and Auto-Initialization

## How Auto-Initialization Works

Pyworks automatically initializes Molten kernels when it detects:
1. A file type/extension that has a matching kernel
2. A notebook with metadata indicating a language with a matching kernel

## Compatibility Matrix

| File/Notebook | Required Kernel | Auto-Init Trigger | Package Required |
|---------------|-----------------|-------------------|------------------|
| `.py` file | `python3` | File opened | `ipykernel` (auto-installed) |
| `.jl` file | `julia` | File opened | `IJulia` (prompted once) |
| `.R` file | `ir` | File opened | `IRkernel` (prompted once) |
| `.ipynb` with Python | `python3` | Language detected from metadata | `ipykernel` (auto-installed) |
| `.ipynb` with Julia | `julia` | Language detected from metadata | `IJulia` (prompted once) |
| `.ipynb` with R | `ir` | Language detected from metadata | `IRkernel` (prompted once) |

## Detection Logic

### For Regular Files
```
File Extension → Language → Check Kernel Availability → Auto-Initialize
    .py     →  Python  →  python3 kernel exists?  →  MoltenInit python3
    .jl     →  Julia   →  julia kernel exists?    →  MoltenInit julia
    .R      →  R       →  ir kernel exists?       →  MoltenInit ir
```

### For Notebooks (.ipynb)
```
Read Metadata → Detect Language → Check Kernel → Auto-Initialize
  metadata.kernelspec.language → python/julia/r → kernel exists? → MoltenInit
```

## When Auto-Init Happens

1. **File Opened** (0ms)
2. **Detector Called** (100ms) - Identifies file type/language
3. **Kernel Check** (150ms) - Verifies compatible kernel exists
4. **Auto-Initialize** (200ms) - Runs `MoltenInit` with appropriate kernel
5. **Ready Notification** (300ms) - "✅ Molten ready with [kernel] kernel"

## When Auto-Init Does NOT Happen

Auto-initialization will NOT occur if:
- The required kernel package is not installed (e.g., IJulia for Julia files)
- Molten.nvim is not installed or loaded
- The file type cannot be determined
- A kernel is already initialized for the buffer

## Fallback Mechanism

If auto-initialization fails or doesn't trigger, keymaps provide a fallback:
- Pressing `<leader>jl` or `<leader>jv` will attempt to initialize the kernel
- This ensures the workflow is never blocked

## Ensuring Kernel Availability

### Python
- **Automatic**: Pyworks installs `ipykernel` automatically when creating virtual environment
- No user action required

### Julia
- **First Time**: Pyworks prompts once to install IJulia
- **Command**: `using Pkg; Pkg.add("IJulia")`
- After installation, auto-init works for all Julia files/notebooks

### R
- **First Time**: Pyworks prompts once to install IRkernel
- **Command**: `install.packages("IRkernel"); IRkernel::installspec()`
- After installation, auto-init works for all R files/notebooks

## Debugging Auto-Initialization

To see what's happening:

```lua
require("pyworks").setup({
  notifications = {
    debug_mode = true
  }
})
```

This will show:
- When files are detected
- Which language is identified
- When kernels are checked
- When auto-init attempts occur

## The Zero-Config Experience

Once kernels are available:
1. Open any supported file
2. Auto-initialization happens in 200ms
3. See notification: "✅ Molten ready with [kernel] kernel"
4. Start using `<leader>jl`, `<leader>jv` immediately

No manual initialization required!