import matplotlib.pyplot as plt
import numpy as np

# Create a simple plot
x = np.linspace(0, 10, 100)
y = np.sin(x)

plt.figure(figsize=(10, 6))
plt.plot(x, y, 'b-', linewidth=2)
plt.title('Test Plot for Image Display')
plt.xlabel('X axis')
plt.ylabel('Y axis')
plt.grid(True)
plt.show()

print("If you see a plot above, image.nvim is working!")