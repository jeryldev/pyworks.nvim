# 🚀 Pyworks.nvim v3.0

> Zero-configuration multi-language support for Python, Julia, and R in Neovim

## ✨ What's New in v3.0

- **Zero Configuration**: Just open files and start coding
- **Automatic Environment Setup**: Virtual environments, kernels, and packages handled automatically
- **Auto-Initialization**: Molten kernels initialize automatically when compatible kernel exists
- **Multi-Language Support**: Python, Julia, and R with consistent workflows
- **Smart Package Detection**: Detects missing packages and installs with `<leader>pi`
- **Jupyter Notebook Support**: View and edit `.ipynb` files seamlessly
- **Performance Optimized**: Aggressive caching and non-blocking operations

## 📦 Installation

Using [lazy.nvim](https://github.com/folke/lazy.nvim):

```lua
{
    "jeryldev/pyworks.nvim",
    dependencies = {
        "nvim-lua/plenary.nvim",  -- Required for testing
    },
    config = function()
        require("pyworks").setup({
            -- All configuration is optional!
            -- Pyworks works with zero configuration
        })
    end,
}
```

## 🎯 Zero Configuration Experience

Just open any supported file and pyworks handles everything:

### Python Files (`.py`)
1. **First time**: Creates `.venv`, installs essentials (pynvim, ipykernel)
2. **Detects imports**: Shows missing packages, press `<leader>pi` to install
3. **Auto-initializes**: Molten with python3 kernel when available (200ms)
4. **Subsequent access**: Silent and instant (< 0.5s)

### Julia Files (`.jl`)
1. **First time**: Checks for Julia, prompts for IJulia if needed
2. **Detects packages**: Shows missing, press `<leader>pi` to install
3. **Auto-initializes**: Molten with julia kernel when IJulia available (200ms)
4. **Project.toml aware**: Activates project environment if found

### R Files (`.R`)
1. **First time**: Checks for R, prompts for IRkernel if needed
2. **Detects libraries**: Shows missing, press `<leader>pi` to install
3. **Auto-initializes**: Molten with ir kernel when IRkernel available (200ms)
4. **renv aware**: Respects R project environments

### Jupyter Notebooks (`.ipynb`)
1. **Auto-detects language**: Python, Julia, or R from metadata
2. **Readable format**: Converts JSON to markdown for viewing
3. **Kernel ready**: Ensures appropriate kernel is installed
4. **Auto-initializes**: Molten with matching kernel when compatible kernel exists (200ms)

## ⚡ Key Features

### Smart Package Management
- **Automatic detection** of imports/using/library statements
- **Package name mapping**: `sklearn` → `scikit-learn`, `cv2` → `opencv-python`
- **Local installation**: Always installs to `.venv`, never globally
- **Compatibility checking**: Warns about version conflicts

### Performance
- **Cached operations**: Package lists, kernel checks, metadata
- **Non-blocking**: All heavy operations run asynchronously
- **Silent when ready**: No notifications when everything is installed
- **Auto-initialization**: Kernels initialize automatically when compatible kernel detected

### Notebook Support
- **Jupytext integration**: View notebooks in readable format
- **Multi-language**: Supports Python, Julia, and R notebooks
- **Auto-sync**: Keep `.py` and `.ipynb` files in sync

## ⌨️ Commands

All commands are optional - pyworks works automatically!

| Command | Description |
|---------|-------------|
| `<leader>pi` | Install missing packages for current file |
| `<leader>jl` | Run current line (auto-initializes kernel if needed) |
| `<leader>jv` | Run visual selection (evaluates highlighted text) |
| `<leader>jr` | Select cell (visually highlights current cell or file) |
| `:PyworksStatus` | Show package status for current file |
| `:PyworksSetup` | Manually trigger environment setup |
| `:PyworksClearCache` | Clear all caches |
| `:checkhealth pyworks` | Run health check |

**Note**: Kernel auto-initialization happens when file type/extension matches an available compatible kernel (python3 for .py/.ipynb with Python, julia for .jl/.ipynb with Julia, ir for .R/.ipynb with R).

## ⚙️ Configuration

Configuration is completely optional. Here are the defaults:

```lua
require("pyworks").setup({
    python = {
        use_uv = false,  -- Use uv instead of pip (if available)
        preferred_venv_name = ".venv",
        auto_install_essentials = true,
        essentials = { "pynvim", "ipykernel", "jupyter_client", "jupytext" },
    },
    julia = {
        auto_install_ijulia = true,
    },
    r = {
        auto_install_irkernel = true,
    },
    notifications = {
        verbose_first_time = true,  -- Show progress on first setup
        silent_when_ready = true,   -- Silent when all packages installed
        show_progress = true,       -- Show progress indicators
    },
})
```

## 🏗️ Architecture

```
pyworks.nvim/
├── plugin/
│   └── pyworks.lua          # Auto-loaded entry point
├── lua/pyworks/
│   ├── init.lua             # Main module and setup
│   ├── core/               # Core infrastructure
│   │   ├── detector.lua    # File detection, routing & auto-init
│   │   ├── cache.lua       # Performance caching
│   │   ├── notifications.lua # Smart notifications
│   │   ├── packages.lua    # Package detection
│   │   └── state.lua       # State management
│   ├── languages/          # Language handlers
│   │   ├── python.lua
│   │   ├── julia.lua
│   │   └── r.lua
│   ├── notebook/           # Notebook support
│   │   └── jupytext.lua
│   └── keymaps.lua         # Keymaps with auto-init fallback
```

## 🧪 Testing

Run the test suite:

```bash
# Basic tests
nvim -u run_tests.vim

# Health check
nvim -c "checkhealth pyworks"

# Test scenarios
nvim tests/scenarios/test_python.py
nvim tests/scenarios/test_julia.jl
nvim tests/scenarios/test_r.R
```

## 📊 Performance Metrics

- **First-time setup**: < 30 seconds (includes package installation)
- **Subsequent file open**: < 0.5 seconds
- **Package detection**: < 1 second
- **Cache hit rate**: > 90%
- **Memory usage**: < 10MB

## 🔄 Migration from v2

If upgrading from v2.x:

```bash
# Run the migration script
./migrate_to_v3.sh

# This will:
# - Backup legacy files
# - Set up new structure
# - Preserve your settings
```

## 🤝 Contributing

Contributions welcome! The codebase is now modular and easy to extend:

1. Language support in `lua/pyworks/languages/`
2. Core features in `lua/pyworks/core/`
3. Notebook features in `lua/pyworks/notebook/`

## 📝 License

MIT License - see LICENSE file for details

## 🙏 Acknowledgments

- Built for the Neovim community
- Inspired by the need for seamless multi-language support
- Special thanks to all contributors

---

**The magic is in the simplicity**: Install, open a file, start coding. Everything else just works. ✨