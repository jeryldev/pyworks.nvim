# Pyworks Auto-Initialization Flow

## Zero-Config Automatic Kernel Initialization

**IMPORTANT**: Auto-initialization happens automatically when the file type/extension or notebook language matches an available compatible kernel:
- Python files (.py) or Python notebooks → python3 kernel (if ipykernel is installed)
- Julia files (.jl) or Julia notebooks → julia kernel (if IJulia is installed)
- R files (.R) or R notebooks → ir kernel (if IRkernel is installed)

### How It Works

1. **File Opened** (any of the 6 scenarios)
   - Autocmd triggers in `plugin/pyworks.lua`
   - Calls `detector.on_file_open()` after 100ms

2. **Detector Routes to Handler**
   - Python (.py) → `handle_python()` → `auto_init_molten("python")`
   - Julia (.jl) → `handle_julia()` → `auto_init_molten("julia")`
   - R (.R) → `handle_r()` → `auto_init_molten("r")`
   - Python notebook (.ipynb) → `handle_python_notebook()` → `auto_init_molten("python")`
   - Julia notebook (.ipynb) → `handle_julia_notebook()` → `auto_init_molten("julia")`
   - R notebook (.ipynb) → `handle_r_notebook()` → `auto_init_molten("r")`

3. **Auto-Initialize Molten** (200ms after file open)
   - Shows: "Setting up [language] kernel for execution..."
   - Runs: `MoltenInit [kernel]`
   - Shows: "✅ Molten ready with [kernel] kernel - Use <leader>jl to run code"

4. **Fallback in Keymaps** (if auto-init failed)
   - When pressing `<leader>jl` or `<leader>jv`
   - Detects if kernel not initialized
   - Shows: "Initializing [kernel] kernel..."
   - Initializes and runs command

### Timeline

```
0ms     - File opened
100ms   - Detector called
200ms   - Auto-init starts
300ms   - Kernel ready notification
        - User can use <leader>jl, <leader>jv immediately
```

### Expected Notifications

#### First Time Opening (with auto-init success):
1. "Setting up [language] kernel for execution..."
2. "✅ Molten ready with [kernel] kernel - Use <leader>jl to run code"
3. [If packages missing] "Missing X packages. Press <leader>pi to install"

#### Subsequent Opening:
- Silent (kernel already initialized from previous session or re-initialized silently)

### Debugging

To debug auto-initialization, set debug mode:
```lua
require("pyworks").setup({
  notifications = {
    debug_mode = true
  }
})
```

Or temporarily:
```vim
:lua vim.g.pyworks_debug = true
```

This will show:
- When files are detected
- When handlers are called
- When auto-init attempts happen

### Common Issues

1. **Auto-init not happening**
   - Check `:messages` for errors
   - Ensure Molten is installed (`:Lazy load molten-nvim`)
   - Check if plugin loaded (`:lua print(vim.g.loaded_pyworks)`)

2. **Kernel not matching file type**
   - Python files → python3 kernel
   - Julia files → julia kernel
   - R files → ir kernel

3. **Notification not showing**
   - Auto-init notifications always show
   - Package notifications only show if packages missing
   - Environment ready only shows first time

### The Zero-Config Promise

**You should NEVER need to:**
- Run `:MoltenInit` manually
- Press `<leader>mi` to initialize
- See "initialize kernel first" errors

**Everything happens automatically for all 6 scenarios when compatible kernels exist!**

### Kernel Compatibility Requirements

For auto-initialization to work:
1. **Python**: Requires `ipykernel` installed (auto-installed by pyworks)
2. **Julia**: Requires `IJulia` package (prompted once if missing)
3. **R**: Requires `IRkernel` package (prompted once if missing)

When a compatible kernel is detected, Molten auto-initializes within 200ms of opening the file.