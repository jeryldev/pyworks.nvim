#!/usr/bin/env python3
"""Test file for leader jl (run current line) functionality"""

# Test single line execution
print("Line 1: Hello")
print("Line 2: World")

# Test with variables
x = 10
y = 20
print(f"x = {x}, y = {y}")

# Test math operations
result = x + y
print(f"Result: {result}")

# Test imports
import math
print(f"Pi: {math.pi}")

# Test function definition
def greet(name):
    return f"Hello, {name}!"

# Test function call
message = greet("User")
print(message)