-- Test script to verify keymaps are set up correctly
print("Testing Pyworks Keymaps Setup")
print("=" .. string.rep("=", 40))

-- Check if Molten is available
local has_molten = vim.fn.exists(":MoltenInit") == 2
print("Molten available: " .. tostring(has_molten))

if has_molten then
    print("\nMolten commands found:")
    local commands = {
        "MoltenInit",
        "MoltenEvaluateLine", 
        "MoltenEvaluateVisual",
        "MoltenReevaluateCell",
        "MoltenDelete",
        "MoltenShowOutput"
    }
    
    for _, cmd in ipairs(commands) do
        local exists = vim.fn.exists(":" .. cmd)
        print("  :" .. cmd .. " = " .. (exists == 2 and "✓" or "✗"))
    end
end

-- Load keymaps module
local ok, keymaps = pcall(require, "pyworks.keymaps")
if ok then
    print("\nPyworks keymaps module loaded successfully")
    
    -- Set up buffer keymaps
    keymaps.setup_buffer_keymaps()
    print("Buffer keymaps set up")
    
    -- Check normal mode keymaps
    print("\nNormal mode keymaps with <leader>j:")
    local n_maps = vim.api.nvim_buf_get_keymap(0, "n")
    for _, map in ipairs(n_maps) do
        if map.lhs and map.lhs:match("<[Ll]eader>j") then
            print("  " .. map.lhs .. " -> " .. (map.desc or "no description"))
        end
    end
    
    -- Check visual mode keymaps
    print("\nVisual mode keymaps with <leader>j:")
    local v_maps = vim.api.nvim_buf_get_keymap(0, "v")
    for _, map in ipairs(v_maps) do
        if map.lhs and map.lhs:match("<[Ll]eader>j") then
            print("  " .. map.lhs .. " -> " .. (map.desc or "no description"))
        end
    end
else
    print("\nError loading keymaps module: " .. tostring(keymaps))
end

print("\n" .. string.rep("=", 40))
print("Test complete. Keymaps should now be active.")