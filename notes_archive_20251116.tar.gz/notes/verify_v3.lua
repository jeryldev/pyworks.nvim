#!/usr/bin/env lua

-- Verification script for pyworks.nvim v3.0
-- This can be run standalone to verify the installation

print("=== Pyworks v3.0 Verification ===\n")

local function check_file(path)
    local f = io.open(path, "r")
    if f then
        f:close()
        return true
    end
    return false
end

local function check_module_structure()
    print("Checking module structure...")
    
    local required_files = {
        "plugin/pyworks.lua",
        "lua/pyworks/init.lua",
        "lua/pyworks/core/detector.lua",
        "lua/pyworks/core/cache.lua",
        "lua/pyworks/core/notifications.lua",
        "lua/pyworks/core/state.lua",
        "lua/pyworks/core/packages.lua",
        "lua/pyworks/languages/python.lua",
        "lua/pyworks/languages/julia.lua",
        "lua/pyworks/languages/r.lua",
        "lua/pyworks/notebook/jupytext.lua",
    }
    
    local all_present = true
    for _, file in ipairs(required_files) do
        if check_file(file) then
            print("  ✓ " .. file)
        else
            print("  ✗ " .. file .. " MISSING!")
            all_present = false
        end
    end
    
    return all_present
end

local function check_test_files()
    print("\nChecking test files...")
    
    local test_files = {
        "tests/scenarios/test_python.py",
        "tests/scenarios/test_julia.jl",
        "tests/scenarios/test_r.R",
        "tests/scenarios/test_python.ipynb",
    }
    
    local all_present = true
    for _, file in ipairs(test_files) do
        if check_file(file) then
            print("  ✓ " .. file)
        else
            print("  ⚠ " .. file .. " (optional)")
        end
    end
    
    return true
end

local function check_legacy_removal()
    print("\nChecking legacy file removal...")
    
    local legacy_files = {
        "lua/pyworks/autocmds.lua",
        "lua/pyworks/auto-install.lua",
        "lua/pyworks/package-detector.lua",
        "lua/pyworks/molten.lua",
        "lua/pyworks/notebooks.lua",
    }
    
    local clean = true
    for _, file in ipairs(legacy_files) do
        if check_file(file) then
            print("  ⚠ Legacy file still present: " .. file)
            clean = false
        else
            print("  ✓ " .. file .. " removed")
        end
    end
    
    return clean
end

-- Run checks
local structure_ok = check_module_structure()
local tests_ok = check_test_files()
local clean_ok = check_legacy_removal()

print("\n=== Verification Results ===")
if structure_ok then
    print("✓ Module structure is correct")
else
    print("✗ Module structure has issues")
end

if tests_ok then
    print("✓ Test files present")
else
    print("⚠ Some test files missing (optional)")
end

if clean_ok then
    print("✓ Legacy files removed")
else
    print("⚠ Some legacy files remain (check backup)")
end

print("\n=== Next Steps ===")
print("1. Open Neovim and run :checkhealth pyworks")
print("2. Test with: nvim tests/scenarios/test_python.py")
print("3. Check package detection with :PyworksStatus")
print("4. Install missing packages with <leader>pi")

if structure_ok then
    print("\n✅ Pyworks v3.0 is ready to use!")
else
    print("\n⚠ Please fix the issues above before using")
end