# Pyworks.nvim Codebase Restructuring Plan

## 📊 Current Structure Analysis

### Current Files Overview:
```
plugin/
├── pyworks.lua         # Plugin loader (minimal, good)
└── jupytext-handler.lua # Jupytext specific handler

lua/pyworks/
├── init.lua            # Main setup (HEAVY - needs refactoring)
├── autocmds.lua        # Autocmds (HEAVY - 600+ lines)
├── commands.lua        # Command definitions
├── config.lua          # Configuration management
├── utils.lua           # Utility functions
├── setup.lua           # Setup wizard
├── diagnostics.lua     # Environment diagnostics
├── notebooks.lua       # Notebook creation/management
├── jupytext.lua        # Jupytext integration
├── molten.lua          # Molten integration
├── molten-safety.lua   # Molten error handling
├── kernel-manager.lua  # Kernel management
├── package-detector.lua # Package detection
├── notebook-essentials.lua # Essential packages
├── auto-install.lua    # Auto installation
├── cell-navigation.lua # Cell navigation
└── check-dependencies.lua # Dependency checking
```

## 🎯 Recommended New Structure

### Keep These Folders Separate:
- **`plugin/`** - Entry point files loaded by Neovim
- **`lua/pyworks/`** - Core implementation (can be renamed to just `lua/` if single module)

### Add These Folders:
- **`doc/`** - Neovim help documentation
- **`ftplugin/`** - Filetype-specific settings
- **`after/`** - Post-load configurations

## 📁 Detailed Restructuring Plan

### 1. CREATE: Core Detection & Routing System

```lua
lua/pyworks/
├── core/
│   ├── detector.lua      # NEW: Universal file detection & routing
│   ├── cache.lua         # NEW: Caching layer (extract from utils)
│   ├── notifications.lua # NEW: Smart notification system
│   └── state.lua         # NEW: Global state management
```

### 2. CREATE: Language-Specific Modules

```lua
lua/pyworks/
├── languages/
│   ├── python/
│   │   ├── init.lua      # Python main handler
│   │   ├── venv.lua      # Virtual environment management
│   │   ├── packages.lua  # Python package detection
│   │   └── kernel.lua    # Python kernel setup
│   ├── julia/
│   │   ├── init.lua      # Julia main handler
│   │   ├── packages.lua  # Julia package detection
│   │   └── kernel.lua    # IJulia kernel setup
│   └── r/
│       ├── init.lua      # R main handler
│       ├── packages.lua  # R package detection
│       └── kernel.lua    # IRkernel setup
```

### 3. REFACTOR: Notebook Support

```lua
lua/pyworks/
├── notebook/
│   ├── init.lua          # REFACTOR from notebooks.lua
│   ├── jupytext.lua      # MOVE: Current jupytext.lua
│   ├── metadata.lua      # NEW: Notebook metadata handling
│   ├── essentials.lua    # MOVE: notebook-essentials.lua
│   └── converter.lua     # NEW: Format conversion logic
```

### 4. REFACTOR: Integration Layer

```lua
lua/pyworks/
├── integrations/
│   ├── molten.lua        # MOVE & SPLIT: Current molten.lua
│   ├── molten_safety.lua # MOVE: molten-safety.lua
│   ├── jupytext.lua      # MOVE: jupytext integration
│   └── image.lua         # NEW: Image.nvim integration
```

### 5. CREATE: Documentation

```
doc/
├── pyworks.txt           # Main help file
├── pyworks-api.txt       # API documentation
└── tags                  # Help tags (auto-generated)

examples/
├── minimal_init.lua      # Minimal config example
├── full_config.lua       # Full config example
└── custom_setup.lua      # Custom setup example
```

### 6. CREATE: Filetype Support

```vim
ftplugin/
├── python.lua            # Python-specific settings
├── julia.lua             # Julia-specific settings
├── r.lua                 # R-specific settings
└── ipynb.lua             # Notebook-specific settings
```

## 🔄 Migration Plan

### Phase 1: Core Infrastructure (Keep existing, add new)

**CREATE NEW FILES:**
1. `lua/pyworks/core/detector.lua` - File detection and routing
2. `lua/pyworks/core/cache.lua` - Extract caching from utils
3. `lua/pyworks/core/notifications.lua` - Smart notifications
4. `lua/pyworks/core/state.lua` - State management

**UPDATE EXISTING:**
1. `plugin/pyworks.lua` - Update to use new detector
2. `lua/pyworks/init.lua` - Simplify, delegate to modules

### Phase 2: Language Modules

**CREATE NEW FILES:**
1. `lua/pyworks/languages/python/init.lua` - Extract from autocmds
2. `lua/pyworks/languages/julia/init.lua` - Extract from autocmds
3. `lua/pyworks/languages/r/init.lua` - Extract from autocmds

**REFACTOR:**
1. Split `autocmds.lua` into language-specific handlers
2. Move package detection logic to language modules

### Phase 3: Clean Up

**DELETE/MERGE:**
1. `auto-install.lua` → Merge into language modules
2. `check-dependencies.lua` → Move to `core/dependencies.lua`
3. Heavy autocmds → Split into language modules

**SIMPLIFY:**
1. `init.lua` - Should only orchestrate, not implement
2. `autocmds.lua` - Should only register, not implement

## 📝 Files to Update

### HIGH PRIORITY - Core Flow:
1. **CREATE** `lua/pyworks/core/detector.lua` - Universal entry point
2. **REFACTOR** `lua/pyworks/autocmds.lua` - Split into modules
3. **REFACTOR** `lua/pyworks/init.lua` - Simplify drastically

### MEDIUM PRIORITY - Organization:
1. **MOVE** Package detection to language modules
2. **MOVE** Kernel logic to language modules  
3. **CREATE** Proper documentation in `doc/`

### LOW PRIORITY - Nice to Have:
1. **CREATE** `ftplugin/` for filetype settings
2. **CREATE** `examples/` folder
3. **CREATE** GitHub Actions for testing

## 🗑️ Files to Consider Removing

1. **MERGE** `auto-install.lua` → Into essentials/packages
2. **MERGE** `cell-navigation.lua` → Into notebook module
3. **SIMPLIFY** `molten-safety.lua` → Into molten integration

## 📋 New File Templates

### `lua/pyworks/core/detector.lua`
```lua
local M = {}
local cache = require("pyworks.core.cache")

function M.on_file_open(filepath)
    -- Detect file type
    -- Route to appropriate handler
    -- Cache results
end

return M
```

### `lua/pyworks/languages/python/init.lua`
```lua
local M = {}

function M.handle_file(filepath)
    -- Check/create venv
    -- Install essentials
    -- Detect packages
    -- Initialize kernel
end

return M
```

### `doc/pyworks.txt`
```vim
*pyworks.txt*  Python environments tailored for Neovim

CONTENTS                                        *pyworks-contents*

1. Introduction.................................|pyworks-intro|
2. Requirements.................................|pyworks-requirements|
3. Installation.................................|pyworks-installation|
4. Usage........................................|pyworks-usage|
5. Commands.....................................|pyworks-commands|
6. Configuration................................|pyworks-config|
```

## 🎯 Benefits of Restructuring

1. **Separation of Concerns** - Each module has single responsibility
2. **Easier Testing** - Can test language modules independently
3. **Better Performance** - Lazy loading of language modules
4. **Cleaner Codebase** - No more 600+ line files
5. **Easier Contribution** - Clear structure for contributors
6. **Progressive Enhancement** - Can add languages without touching core

## 📊 Implementation Priority

### Week 1: Core Infrastructure
- Create detector.lua
- Create cache.lua
- Create notifications.lua
- Update plugin/pyworks.lua

### Week 2: Python Support
- Create python module structure
- Extract Python logic from autocmds
- Test Python workflow

### Week 3: Julia & R Support
- Create Julia module
- Create R module
- Test multi-language support

### Week 4: Documentation & Polish
- Write help documentation
- Create examples
- Clean up old code

## ⚠️ Backward Compatibility

### Keep Working:
- All existing commands
- All existing keybindings
- Current configuration format

### Deprecate Gradually:
- Old module paths (with warnings)
- Redundant commands
- Complex setup requirements

## 🚀 Migration Commands

```bash
# Create new structure
mkdir -p lua/pyworks/{core,languages/{python,julia,r},notebook,integrations}
mkdir -p {doc,ftplugin,examples}

# Move files
git mv lua/pyworks/jupytext.lua lua/pyworks/notebook/
git mv lua/pyworks/molten.lua lua/pyworks/integrations/
```

## 📈 Success Metrics

- File size: No file > 300 lines
- Load time: < 10ms startup impact
- Memory: < 5MB runtime usage
- Coverage: 100% of user stories supported
- Zero-config: Works without any setup

## 🎉 End Result

A clean, modular, performant plugin that:
1. Just works when opening files
2. Has clear separation of concerns
3. Is easy to maintain and extend
4. Follows Neovim best practices
5. Provides excellent user experience