# Add this at the beginning of your Python files/notebooks to prevent GUI windows

import matplotlib
matplotlib.use('Agg')  # Agg = Anti-Grain Geometry, a non-interactive backend

# Or use inline backend if available (better for Jupyter-like environments)
try:
    get_ipython().run_line_magic('matplotlib', 'inline')
except:
    # Not in IPython/Jupyter environment
    pass

# Now all plots will display inline in Molten without opening external windows