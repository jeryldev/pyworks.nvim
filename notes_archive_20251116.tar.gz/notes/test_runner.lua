-- Simple test runner for pyworks.nvim
-- Tests the 6 core scenarios

local function test_python_file()
    print("Testing Python file...")
    local detector = require("pyworks.core.detector")
    detector.on_file_open("tests/scenarios/test_python.py")
    
    vim.wait(1000)
    
    local packages = require("pyworks.core.packages")
    local result = packages.analyze_buffer("python")
    
    print(string.format("  Imports found: %d", #result.imports))
    print(string.format("  Missing packages: %d", #result.missing))
    
    return #result.imports > 0
end

local function test_julia_file()
    print("Testing Julia file...")
    local detector = require("pyworks.core.detector")
    detector.on_file_open("tests/scenarios/test_julia.jl")
    
    vim.wait(1000)
    
    local packages = require("pyworks.core.packages")
    local result = packages.analyze_buffer("julia")
    
    print(string.format("  Imports found: %d", #result.imports))
    print(string.format("  Missing packages: %d", #result.missing))
    
    return #result.imports > 0
end

local function test_r_file()
    print("Testing R file...")
    local detector = require("pyworks.core.detector")
    detector.on_file_open("tests/scenarios/test_r.R")
    
    vim.wait(1000)
    
    local packages = require("pyworks.core.packages")
    local result = packages.analyze_buffer("r")
    
    print(string.format("  Imports found: %d", #result.imports))
    print(string.format("  Missing packages: %d", #result.missing))
    
    return #result.imports > 0
end

local function test_cache()
    print("Testing cache...")
    local cache = require("pyworks.core.cache")
    
    -- Test set and get
    cache.set("test_key", "test_value")
    local value = cache.get("test_key")
    assert(value == "test_value", "Cache set/get failed")
    
    -- Test invalidation
    cache.invalidate("test_key")
    value = cache.get("test_key")
    assert(value == nil, "Cache invalidation failed")
    
    print("  Cache tests passed")
    return true
end

local function test_package_mappings()
    print("Testing package mappings...")
    local packages = require("pyworks.core.packages")
    
    -- Test Python mappings
    assert(packages.map_import_to_package("sklearn", "python") == "scikit-learn")
    assert(packages.map_import_to_package("cv2", "python") == "opencv-python")
    assert(packages.map_import_to_package("PIL", "python") == "Pillow")
    assert(packages.map_import_to_package("bs4", "python") == "beautifulsoup4")
    
    print("  Package mapping tests passed")
    return true
end

-- Run all tests
local function run_tests()
    print("\n=== Pyworks.nvim Test Suite ===\n")
    
    -- Initialize the plugin
    require("pyworks").setup({
        notifications = {
            debug_mode = true,
        }
    })
    
    local tests = {
        { name = "Cache", fn = test_cache },
        { name = "Package Mappings", fn = test_package_mappings },
        { name = "Python File", fn = test_python_file },
        { name = "Julia File", fn = test_julia_file },
        { name = "R File", fn = test_r_file },
    }
    
    local passed = 0
    local failed = 0
    
    for _, test in ipairs(tests) do
        local ok, result = pcall(test.fn)
        if ok and result then
            passed = passed + 1
            print(string.format("✓ %s test passed", test.name))
        else
            failed = failed + 1
            print(string.format("✗ %s test failed: %s", test.name, tostring(result)))
        end
    end
    
    print(string.format("\n=== Results: %d passed, %d failed ===\n", passed, failed))
end

-- Run if executed directly
if vim.fn.has("nvim-0.7") == 1 then
    run_tests()
else
    print("Tests require Neovim 0.7 or later")
end