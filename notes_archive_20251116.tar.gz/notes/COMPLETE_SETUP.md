# 🚀 Pyworks.nvim Complete Setup

## Essential Components for ALL 6 Scenarios

The following are **REQUIRED** for the complete experience across all file types:

### Core Components:
1. **Pyworks.nvim** - Environment and package management
2. **Molten.nvim** - Cell execution and kernel management  
3. **image.nvim** - Plot and image display
4. **Jupytext** - Notebook viewing (installed by Pyworks)

## The 6 Scenarios (All Use Molten + Image)

| File Type | What Happens | Molten Kernel | Image Support |
|-----------|-------------|---------------|---------------|
| **1. Python .py** | Creates .venv, installs packages | `python3` | ✅ Plots displayed inline |
| **2. Julia .jl** | Checks Julia, installs IJulia | `julia` | ✅ Plots displayed inline |
| **3. R .R** | Checks R, installs IRkernel | `ir` | ✅ Plots displayed inline |
| **4. Python .ipynb** | Jupytext view + Python kernel | `python3` | ✅ Plots displayed inline |
| **5. Julia .ipynb** | Jupytext view + Julia kernel | `julia` | ✅ Plots displayed inline |
| **6. R .ipynb** | Jupytext view + R kernel | `ir` | ✅ Plots displayed inline |

## Complete Configuration

```lua
-- ~/.config/nvim/lua/plugins/pyworks-setup.lua
return {
  {
    -- Pyworks for environment management
    dir = "/Users/jeryldev/PycharmProjects/iron_training/pyworks.nvim",
    dependencies = {
      "nvim-lua/plenary.nvim",
    },
    lazy = false,
    config = function()
      require("pyworks").setup({
        python = {
          preferred_venv_name = ".venv",
          use_uv = true,
          auto_install_essentials = true,
          essentials = { "pynvim", "ipykernel", "jupyter_client", "jupytext" },
        },
        julia = {
          auto_install_ijulia = true,
        },
        r = {
          auto_install_irkernel = true,
        },
        notifications = {
          verbose_first_time = true,
          silent_when_ready = true,
          show_progress = true,
        },
      })
    end,
  },

  -- ESSENTIAL: Molten for ALL scenarios
  {
    "benlubas/molten-nvim",
    version = "^1.0.0",
    build = ":UpdateRemotePlugins",
    dependencies = {
      "3rd/image.nvim",
    },
    init = function()
      vim.g.molten_image_provider = "image.nvim"
      vim.g.molten_output_win_max_height = 40
      vim.g.molten_output_win_max_width = 150
      vim.g.molten_auto_open_output = true
      vim.g.molten_output_crop_border = true
      vim.g.molten_wrap_output = true
      vim.g.molten_virt_text_output = true
    end,
  },
  
  -- ESSENTIAL: Image display for ALL scenarios
  {
    "3rd/image.nvim",
    opts = {
      backend = "kitty",  -- Required: Kitty or compatible terminal
      integrations = {
        markdown = { enabled = true },
      },
      max_width = 150,
      max_height = 40,
      max_height_window_percentage = math.huge,
      max_width_window_percentage = math.huge,
      window_overlap_clear_enabled = true,
    },
  }
}
```

## Universal Keymaps (Work for ALL 6 Scenarios)

### Cell Execution (Molten)
| Keymap | Description | Python | Julia | R | Notebooks |
|--------|-------------|--------|-------|---|-----------|
| `<leader>mi` | Initialize kernel | ✅ | ✅ | ✅ | ✅ |
| `<leader>jl` | Run current line | ✅ | ✅ | ✅ | ✅ |
| `<leader>jv` | Run visual selection | ✅ | ✅ | ✅ | ✅ |
| `<leader>jr` | Run current cell | ✅ | ✅ | ✅ | ✅ |
| `<leader>jc` | Re-evaluate cell | ✅ | ✅ | ✅ | ✅ |
| `<leader>jd` | Delete output | ✅ | ✅ | ✅ | ✅ |
| `<leader>jo` | Show/hide output | ✅ | ✅ | ✅ | ✅ |

### Package Management (Pyworks)
| Keymap | Description | Python | Julia | R | Notebooks |
|--------|-------------|--------|-------|---|-----------|
| `<leader>pi` | Install missing packages | ✅ | ✅ | ✅ | ✅ |

## Workflow for Each Scenario

### Scenario 1: Python File (.py)
```python
# test.py
import matplotlib.pyplot as plt
import numpy as np

# %%
x = np.linspace(0, 10, 100)
y = np.sin(x)
plt.plot(x, y)
plt.show()  # Image displays inline with image.nvim!
```

1. Open file → Pyworks creates .venv, installs packages
2. `<leader>mi` → Initialize python3 kernel with Molten
3. `<leader>jr` → Run cell, see plot inline

### Scenario 2: Julia File (.jl)
```julia
# test.jl
using Plots

# %%
x = 0:0.1:10
y = sin.(x)
plot(x, y)  # Image displays inline!
```

1. Open file → Pyworks checks Julia, prompts for IJulia
2. `<leader>mi` → Initialize julia kernel with Molten
3. `<leader>jr` → Run cell, see plot inline

### Scenario 3: R File (.R)
```r
# test.R
library(ggplot2)

# %%
data <- data.frame(x = 1:10, y = rnorm(10))
ggplot(data, aes(x, y)) + geom_point()  # Image displays inline!
```

1. Open file → Pyworks checks R, prompts for IRkernel
2. `<leader>mi` → Initialize ir kernel with Molten
3. `<leader>jr` → Run cell, see plot inline

### Scenarios 4-6: Notebooks (.ipynb)
For ANY notebook (Python/Julia/R):
1. Open .ipynb → Jupytext converts to readable format
2. `<leader>mi` → Auto-detects and initializes correct kernel
3. `<leader>jr` → Run cells with full output display
4. `<leader>mn` → Import existing notebook outputs

## Installation Checklist

- [ ] Neovim 0.9+ with Python support
- [ ] Kitty terminal (or compatible for image.nvim)
- [ ] Python 3.8+ installed
- [ ] Julia installed (for Julia support)
- [ ] R installed (for R support)
- [ ] Run `:UpdateRemotePlugins` after installing Molten
- [ ] Run `:checkhealth molten` to verify setup

## Why This Setup?

- **Pyworks**: Handles ALL environment setup automatically
- **Molten**: Provides consistent cell execution across ALL languages
- **image.nvim**: Displays plots/images for ALL languages
- **Jupytext**: Makes notebooks readable for ALL languages

This gives you a **complete Jupyter experience** in Neovim for all 6 scenarios!

## Troubleshooting

### Images not showing?
- Ensure you're using Kitty terminal
- Check `:checkhealth image`

### Molten not working?
- Run `:UpdateRemotePlugins`
- Check `:checkhealth molten`

### Kernel not found?
- Python: Pyworks installs ipykernel automatically
- Julia: Accept prompt to install IJulia
- R: Accept prompt to install IRkernel

## Summary

**Every file type** (.py, .jl, .R, .ipynb) uses:
- ✅ Molten for execution
- ✅ image.nvim for plots
- ✅ Same keymaps
- ✅ Same workflow

The only difference is which kernel Molten uses:
- Python → `python3`
- Julia → `julia`  
- R → `ir`

Everything else is identical across all 6 scenarios!