# %% Configure matplotlib for inline display
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import numpy as np

# %% Create a simple plot
x = np.linspace(0, 10, 100)
y = np.sin(x)

plt.figure(figsize=(10, 6))
plt.plot(x, y, 'b-', linewidth=2)
plt.title('Test Plot for Inline Display')
plt.xlabel('X axis')
plt.ylabel('Y axis')
plt.grid(True)

# Don't use plt.show() - just display the figure
plt.gcf()  # Get current figure for display

# %% Alternative: explicitly show without GUI
# You can also use:
# display(plt.gcf())  # if using IPython display
# or just let Molten capture the output automatically