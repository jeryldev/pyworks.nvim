# Pyworks.nvim Implementation Plan

## 🎯 Goal: Unified Zero-Config Experience for All 6 Scenarios

### The 6 Core Scenarios:
1. **Python .py** - Virtual environment + packages
2. **Julia .jl** - IJulia kernel + packages
3. **R .R** - IRkernel + packages
4. **Python .ipynb** - Jupytext + venv + kernel + packages
5. **Julia .ipynb** - Jupytext + Julia kernel + packages
6. **R .ipynb** - Jupytext + R kernel + packages

## 🏗️ Core Architecture

### 1. File Detection & Routing System

```lua
-- lua/pyworks/detector.lua

local M = {}

function M.on_file_open(filepath)
    local ext = vim.fn.fnamemodify(filepath, ":e")
    local ft = vim.bo.filetype
    
    -- Route to appropriate handler
    if ext == "ipynb" then
        handle_notebook(filepath)
    elseif ext == "py" or ft == "python" then
        handle_python(filepath)
    elseif ext == "jl" or ft == "julia" then
        handle_julia(filepath)
    elseif ext == "R" or ft == "r" then
        handle_r(filepath)
    end
end

function handle_notebook(filepath)
    -- Step 1: Ensure jupytext is available
    ensure_jupytext()
    
    -- Step 2: Read notebook metadata to detect language
    local language = detect_notebook_language(filepath)
    
    -- Step 3: Route to language-specific handler
    if language == "julia" then
        handle_julia_notebook(filepath)
    elseif language == "R" then
        handle_r_notebook(filepath)
    else  -- Default to Python
        handle_python_notebook(filepath)
    end
end
```

### 2. Environment Management Layer

```lua
-- lua/pyworks/environments.lua

local M = {}

-- Python: Always use local .venv
function M.ensure_python_env()
    if not has_venv() then
        create_venv()  -- Respects use_uv setting
    end
    validate_venv()
    ensure_essentials()  -- pynvim, ipykernel, jupyter_client
    return true
end

-- Julia: Check for IJulia kernel
function M.ensure_julia_env()
    if not has_julia() then
        notify("Julia not found. Please install Julia first")
        return false
    end
    if not has_ijulia() then
        prompt_install_ijulia()
    end
    return true
end

-- R: Check for IRkernel
function M.ensure_r_env()
    if not has_r() then
        notify("R not found. Please install R first")
        return false
    end
    if not has_irkernel() then
        prompt_install_irkernel()
    end
    return true
end
```

### 3. Package Detection & Installation

```lua
-- lua/pyworks/packages.lua

local M = {}

-- Universal package detector
function M.detect_missing_packages(filepath, language)
    local imports = scan_imports(filepath, language)
    local installed = get_installed_packages(language)
    local missing = {}
    
    for _, pkg in ipairs(imports) do
        local mapped_name = map_package_name(pkg, language)
        if not installed[mapped_name] then
            table.insert(missing, mapped_name)
        end
    end
    
    return missing
end

-- Language-specific scanners
function scan_imports(filepath, language)
    if language == "python" then
        return scan_python_imports(filepath)  -- import, from...import
    elseif language == "julia" then
        return scan_julia_imports(filepath)   -- using, import
    elseif language == "r" then
        return scan_r_imports(filepath)       -- library(), require()
    end
end

-- Installation orchestrator
function M.install_packages(packages, language)
    if language == "python" then
        install_python_packages(packages)
    elseif language == "julia" then
        install_julia_packages(packages)
    elseif language == "r" then
        install_r_packages(packages)
    end
end
```

### 4. Caching Strategy

```lua
-- lua/pyworks/cache.lua

local M = {}
local cache = {}

-- Cache with TTL
local cache_ttl = {
    jupytext_check = 3600,    -- 1 hour (rarely changes)
    venv_check = 30,          -- 30 seconds
    kernel_list = 60,         -- 1 minute
    installed_packages = 300,  -- 5 minutes
    notebook_metadata = 120,   -- 2 minutes
}

function M.get(key)
    local entry = cache[key]
    if not entry then return nil end
    
    local now = os.time()
    if now - entry.timestamp > cache_ttl[key] then
        cache[key] = nil
        return nil
    end
    
    return entry.value
end

function M.set(key, value)
    cache[key] = {
        value = value,
        timestamp = os.time()
    }
end
```

### 5. Notification System

```lua
-- lua/pyworks/notifications.lua

local M = {}

-- Smart notification levels
function M.notify(message, level, options)
    options = options or {}
    
    -- First-time: verbose
    -- Subsequent: silent unless action needed
    if options.first_time then
        vim.notify(message, level or vim.log.levels.INFO)
    elseif options.action_required then
        vim.notify(message, vim.log.levels.WARN)
    elseif options.error then
        vim.notify(message, vim.log.levels.ERROR)
    end
end

-- Progress notifications
function M.progress(title, message)
    -- Use vim.notify with progress extension if available
    -- Or fallback to simple notification
end
```

## 📊 Implementation Flow Diagrams

### Universal Entry Point

```mermaid
graph TD
    Start[File Opened] --> Detect[Detect File Type]
    Detect --> IsNotebook{Is .ipynb?}
    
    IsNotebook -->|Yes| CheckJupytext[Ensure Jupytext]
    IsNotebook -->|No| RouteByExt[Route by Extension]
    
    CheckJupytext --> ReadMeta[Read Metadata]
    ReadMeta --> DetectLang[Detect Language]
    DetectLang --> RouteByLang[Route to Handler]
    
    RouteByExt -->|.py| PythonFlow
    RouteByExt -->|.jl| JuliaFlow
    RouteByExt -->|.R| RFlow
    
    RouteByLang -->|Python| PythonNotebookFlow
    RouteByLang -->|Julia| JuliaNotebookFlow
    RouteByLang -->|R| RNotebookFlow
```

### Python Flow (.py and .ipynb)

```mermaid
graph TD
    PythonStart[Python File/Notebook] --> CheckVenv{Has .venv?}
    
    CheckVenv -->|No| CreateVenv[Create .venv]
    CheckVenv -->|Yes| ValidateVenv[Validate .venv]
    
    CreateVenv --> CheckUV{use_uv = true?}
    CheckUV -->|Yes & Available| CreateWithUV[uv venv .venv]
    CheckUV -->|No/Not Available| CreateWithPip[python -m venv]
    
    CreateWithUV --> InstallEssentials
    CreateWithPip --> InstallEssentials
    ValidateVenv --> CheckEssentials{Has essentials?}
    
    CheckEssentials -->|No| InstallEssentials[Install pynvim, ipykernel, etc]
    CheckEssentials -->|Yes| ScanImports
    
    InstallEssentials --> ScanImports[Scan for imports]
    ScanImports --> CheckPackages{Missing packages?}
    
    CheckPackages -->|Yes| ShowNotification[Show missing + leader-pi]
    CheckPackages -->|No| Silent[Silent - Ready]
```

### Julia Flow (.jl and .ipynb)

```mermaid
graph TD
    JuliaStart[Julia File/Notebook] --> CheckJulia{Julia installed?}
    
    CheckJulia -->|No| ErrorMsg[Show install Julia message]
    CheckJulia -->|Yes| CheckIJulia{Has IJulia?}
    
    CheckIJulia -->|No| PromptInstall[Prompt to install IJulia]
    CheckIJulia -->|Yes| CheckProject{Has Project.toml?}
    
    PromptInstall --> InstallIJulia[Pkg.add IJulia]
    
    CheckProject -->|Yes| ActivateProject[Pkg.activate(.)]
    CheckProject -->|No| UseGlobal[Use global env]
    
    ActivateProject --> ScanUsing
    UseGlobal --> ScanUsing[Scan using/import]
    InstallIJulia --> ScanUsing
    
    ScanUsing --> CheckPkgs{Missing packages?}
    CheckPkgs -->|Yes| ShowNotification[Show missing + leader-pi]
    CheckPkgs -->|No| Silent[Silent - Ready]
```

### R Flow (.R and .ipynb)

```mermaid
graph TD
    RStart[R File/Notebook] --> CheckR{R installed?}
    
    CheckR -->|No| ErrorMsg[Show install R message]
    CheckR -->|Yes| CheckIRkernel{Has IRkernel?}
    
    CheckIRkernel -->|No| PromptInstall[Prompt to install IRkernel]
    CheckIRkernel -->|Yes| ScanLibrary[Scan library() calls]
    
    PromptInstall --> InstallIRkernel[install.packages IRkernel]
    InstallIRkernel --> RegisterKernel[IRkernel::installspec()]
    RegisterKernel --> ScanLibrary
    
    ScanLibrary --> CheckPkgs{Missing packages?}
    CheckPkgs -->|Yes| ShowNotification[Show missing + leader-pi]
    CheckPkgs -->|No| Silent[Silent - Ready]
```

## 🔄 Autocmd Registration

```lua
-- plugin/pyworks.lua

vim.api.nvim_create_autocmd({"BufReadPost", "BufNewFile"}, {
    pattern = {"*.py", "*.jl", "*.R", "*.ipynb"},
    callback = function(ev)
        -- Use vim.defer_fn for non-blocking
        vim.defer_fn(function()
            require("pyworks.detector").on_file_open(ev.file)
        end, 100)  -- Small delay to let buffer settle
    end,
})

-- Re-scan on save for new imports
vim.api.nvim_create_autocmd("BufWritePost", {
    pattern = {"*.py", "*.jl", "*.R", "*.ipynb"},
    callback = function(ev)
        require("pyworks.packages").rescan_imports(ev.file)
    end,
})
```

## 📦 Key Implementation Files

### Core Files to Create/Modify:

1. **lua/pyworks/detector.lua** - File type detection and routing
2. **lua/pyworks/environments.lua** - Environment management (venv, kernels)
3. **lua/pyworks/packages.lua** - Package detection and installation
4. **lua/pyworks/cache.lua** - Caching layer for performance
5. **lua/pyworks/notifications.lua** - Smart notification system
6. **lua/pyworks/jupytext.lua** - Notebook handling
7. **lua/pyworks/kernels.lua** - Kernel management for all languages

### Language-Specific Handlers:

1. **lua/pyworks/languages/python.lua** - Python-specific logic
2. **lua/pyworks/languages/julia.lua** - Julia-specific logic
3. **lua/pyworks/languages/r.lua** - R-specific logic

## ⚡ Performance Optimizations

### 1. Aggressive Caching
- Cache everything expensive (kernel lists, package lists, etc.)
- Use appropriate TTLs (5 seconds to 1 hour)
- Invalidate cache on explicit actions

### 2. Async Operations
- Use `vim.fn.jobstart()` for long-running commands
- Show progress indicators
- Never block the UI

### 3. Lazy Loading
- Don't load language modules until needed
- Defer expensive checks until file is actually opened

### 4. Smart Defaults
- Python for unknown notebooks
- .venv for Python environments
- Common package name mappings

## 🎯 Success Criteria

### First-Time Experience (Any File):
- ✅ Automatic environment setup
- ✅ Clear progress indicators
- ✅ Helpful notifications
- ✅ One-click package installation
- ✅ Total time: 30s-3min depending on language

### Subsequent Access (Any File):
- ✅ < 0.5 second to ready
- ✅ Completely silent when everything is installed
- ✅ Cached checks for performance
- ✅ Only notifies for new missing packages

### Package Management:
- ✅ Accurate detection across all languages
- ✅ Smart package name mapping
- ✅ Compatibility checking (Python)
- ✅ Respects existing environments

### Universal Experience:
- ✅ No :PyworksSetup required
- ✅ Consistent behavior across languages
- ✅ Zero configuration needed
- ✅ Just open file and start working

## 📋 Implementation Priority

### Phase 1: Core Infrastructure
1. File detection and routing
2. Caching layer
3. Notification system
4. Autocmd registration

### Phase 2: Python Support (Most Common)
1. Virtual environment management
2. Package detection for Python
3. Jupyter kernel setup
4. Python notebook support

### Phase 3: Julia & R Support
1. Julia kernel detection
2. R kernel detection
3. Package detection for Julia/R
4. Multi-language notebooks

### Phase 4: Polish & Optimization
1. Performance tuning
2. Better error handling
3. Progress indicators
4. Documentation

## 🧪 Testing Strategy

### Unit Tests:
- Package name mapping
- Import detection patterns
- Cache TTL logic
- Environment detection

### Integration Tests:
- Full flow for each file type
- First-time vs subsequent access
- Package installation
- Kernel initialization

### Manual Testing Scenarios:
1. Fresh project, no environment
2. Existing project with venv
3. Notebook with missing metadata
4. Multi-language project
5. Slow network conditions
6. Missing language runtime

## 📝 Configuration

```lua
-- Minimal configuration, smart defaults
require("pyworks").setup({
    python = {
        use_uv = true,  -- Prefer uv for speed
        preferred_venv_name = ".venv",
    },
    cache = {
        -- Optional: override cache TTLs
        kernel_list = 60,
        installed_packages = 300,
    },
    notifications = {
        verbose_first_time = true,
        silent_when_ready = true,
    }
})
```

## 🚀 Migration Path

### From Current Implementation:
1. Preserve existing commands (:PyworksSetup remains optional)
2. Add new zero-config flow alongside
3. Gradually migrate users to new flow
4. Deprecate manual setup over time

### Backward Compatibility:
- Existing configs continue to work
- :PyworksSetup becomes power-user tool
- All current features preserved

## 📊 Metrics for Success

- Time to first execution: < 3 minutes (first time)
- Time to ready (subsequent): < 0.5 seconds
- User interventions required: 1 (package install confirmation)
- Configuration required: 0 lines
- Documentation needed: Minimal

## 🎯 End Goal

**The Magic Experience:**
1. User installs pyworks.nvim
2. User opens ANY supported file
3. Everything just works
4. No documentation needed
5. No configuration required
6. Fast, silent, and reliable

## 📁 Codebase Restructuring

### New Folder Structure:
```
pyworks.nvim/
├── plugin/                 # Entry points (keep minimal)
│   └── pyworks.lua
├── lua/
│   └── pyworks/
│       ├── core/          # Core infrastructure
│       │   ├── detector.lua
│       │   ├── cache.lua
│       │   ├── notifications.lua
│       │   └── state.lua
│       ├── languages/     # Language-specific handlers
│       │   ├── python/
│       │   ├── julia/
│       │   └── r/
│       ├── notebook/      # Notebook support
│       │   ├── jupytext.lua
│       │   ├── metadata.lua
│       │   └── essentials.lua
│       └── integrations/  # External tool integrations
│           ├── molten.lua
│           └── image.lua
├── tests/                 # Test files for all scenarios
│   ├── scenarios/        # Test scenario files
│   │   ├── test_python.py
│   │   ├── test_julia.jl
│   │   ├── test_r.R
│   │   ├── test_python.ipynb
│   │   ├── test_julia.ipynb
│   │   └── test_r.ipynb
│   ├── specs/           # Test specifications
│   │   └── *_spec.lua
│   └── fixtures/        # Test data
├── doc/                  # Neovim help documentation
│   ├── pyworks.txt
│   └── tags
├── ftplugin/            # Filetype-specific settings
│   ├── python.lua
│   ├── julia.lua
│   └── r.lua
└── examples/            # Configuration examples
    └── configs/

## 🧪 Testing Strategy

### Test Framework:
- Use `plenary.nvim` for Lua testing
- Create scenario files that simulate real usage
- Test both first-time and subsequent access

### The 6 Core Test Scenarios:

#### 1. Python File Test (`tests/scenarios/test_python.py`):
```python
# Test imports for package detection
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import requests

# Test code
data = pd.DataFrame({'x': [1, 2, 3], 'y': [4, 5, 6]})
plt.plot(data.x, data.y)
```

#### 2. Julia File Test (`tests/scenarios/test_julia.jl`):
```julia
# Test using statements
using DataFrames
using Plots
using Statistics
import CSV

# Test code
data = DataFrame(x = 1:10, y = rand(10))
plot(data.x, data.y)
```

#### 3. R File Test (`tests/scenarios/test_r.R`):
```r
# Test library calls
library(ggplot2)
library(dplyr)
library(tidyverse)

# Test code
data <- data.frame(x = 1:10, y = rnorm(10))
ggplot(data, aes(x = x, y = y)) + geom_point()
```

#### 4-6. Notebook Tests:
Create `.ipynb` versions with appropriate metadata for each language.

### Test Specifications (`tests/specs/`):

```lua
-- tests/specs/python_spec.lua
describe("Python file handling", function()
  it("creates venv on first access", function()
    -- Test venv creation
  end)
  
  it("detects missing packages", function()
    -- Test package detection
  end)
  
  it("is silent on second access", function()
    -- Test caching and silence
  end)
end)
```

### Test Execution:
```bash
# Run all tests
make test

# Run specific scenario
nvim --headless -c "PlenaryBustedFile tests/specs/python_spec.lua"
```

## 📋 Comprehensive Implementation Todo List

### Phase 0: Setup & Structure
- [ ] Create new folder structure (`tests/`, `doc/`, etc.)
- [ ] Set up plenary.nvim testing framework
- [ ] Create test scenario files for all 6 cases
- [ ] Write initial test specifications
- [ ] Set up GitHub Actions for CI

### Phase 1: Core Infrastructure
- [ ] Create `lua/pyworks/core/detector.lua`
- [ ] Create `lua/pyworks/core/cache.lua`
- [ ] Create `lua/pyworks/core/notifications.lua`
- [ ] Create `lua/pyworks/core/state.lua`
- [ ] Update `plugin/pyworks.lua` to use detector
- [ ] Write tests for core modules

### Phase 2: Python Implementation
- [ ] Create `lua/pyworks/languages/python/init.lua`
- [ ] Create `lua/pyworks/languages/python/venv.lua`
- [ ] Create `lua/pyworks/languages/python/packages.lua`
- [ ] Create `lua/pyworks/languages/python/kernel.lua`
- [ ] Extract Python logic from `autocmds.lua`
- [ ] Test Python .py scenario
- [ ] Test Python .ipynb scenario

### Phase 3: Julia Implementation
- [ ] Create `lua/pyworks/languages/julia/init.lua`
- [ ] Create `lua/pyworks/languages/julia/packages.lua`
- [ ] Create `lua/pyworks/languages/julia/kernel.lua`
- [ ] Extract Julia logic from `autocmds.lua`
- [ ] Test Julia .jl scenario
- [ ] Test Julia .ipynb scenario

### Phase 4: R Implementation
- [ ] Create `lua/pyworks/languages/r/init.lua`
- [ ] Create `lua/pyworks/languages/r/packages.lua`
- [ ] Create `lua/pyworks/languages/r/kernel.lua`
- [ ] Extract R logic from `autocmds.lua`
- [ ] Test R .R scenario
- [ ] Test R .ipynb scenario

### Phase 5: Notebook Support
- [ ] Refactor `lua/pyworks/notebooks.lua`
- [ ] Create `lua/pyworks/notebook/metadata.lua`
- [ ] Create `lua/pyworks/notebook/converter.lua`
- [ ] Improve jupytext integration
- [ ] Test all notebook scenarios

### Phase 6: Integration & Polish
- [ ] Refactor Molten integration
- [ ] Add image.nvim support
- [ ] Create ftplugin files
- [ ] Optimize performance (caching, lazy loading)
- [ ] Add progress indicators

### Phase 7: Documentation
- [ ] Write `doc/pyworks.txt` help file
- [ ] Create example configurations
- [ ] Update README.md
- [ ] Create contribution guide
- [ ] Add inline code documentation

### Phase 8: Cleanup
- [ ] Remove deprecated code
- [ ] Merge redundant modules
- [ ] Simplify `init.lua`
- [ ] Reduce file sizes (< 300 lines each)
- [ ] Final testing of all scenarios

### Phase 9: Release Preparation
- [ ] Version bump to 3.0.0
- [ ] Update CHANGELOG.md
- [ ] Create migration guide
- [ ] Test backward compatibility
- [ ] Create release notes

## 🎯 Success Criteria for Each Scenario

### Test Matrix:

| Scenario | First Time | Second Time | New Package |
|----------|------------|-------------|-------------|
| Python.py | ✅ Create venv, detect packages | ✅ Silent, < 0.5s | ✅ Detect only new |
| Julia.jl | ✅ Install IJulia, detect packages | ✅ Silent, < 0.5s | ✅ Detect only new |
| R.R | ✅ Install IRkernel, detect packages | ✅ Silent, < 0.5s | ✅ Detect only new |
| Python.ipynb | ✅ Jupytext + venv + kernel | ✅ Silent, < 0.5s | ✅ Detect only new |
| Julia.ipynb | ✅ Jupytext + IJulia | ✅ Silent, < 0.5s | ✅ Detect only new |
| R.ipynb | ✅ Jupytext + IRkernel | ✅ Silent, < 0.5s | ✅ Detect only new |

### Performance Targets:
- First-time setup: < 3 minutes
- Subsequent access: < 0.5 seconds
- Package detection: < 1 second
- Cache hit rate: > 90%
- Memory usage: < 10MB

## 🚀 Development Workflow

1. **Create test first** - Write test for scenario
2. **Implement feature** - Make test pass
3. **Refactor** - Clean up implementation
4. **Document** - Add help and examples
5. **Benchmark** - Ensure performance targets

## 📊 Progress Tracking

Use GitHub Projects or Issues to track:
- [ ] Each todo item
- [ ] Test coverage percentage
- [ ] Performance benchmarks
- [ ] User feedback
- [ ] Bug reports