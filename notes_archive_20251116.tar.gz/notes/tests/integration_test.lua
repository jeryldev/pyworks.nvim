#!/usr/bin/env lua
-- Integration tests for pyworks.nvim
-- These tests actually verify that package installation works

local function setup_test_environment()
    -- Create a temporary test directory
    local test_dir = "/tmp/pyworks_test_" .. os.time()
    os.execute("mkdir -p " .. test_dir)
    return test_dir
end

local function cleanup_test_environment(test_dir)
    os.execute("rm -rf " .. test_dir)
end

local function test_venv_creation(test_dir)
    print("\n[TEST] Virtual environment creation")
    
    -- Change to test directory
    local original_dir = os.getenv("PWD")
    os.execute("cd " .. test_dir)
    
    -- Test venv creation with python3
    local cmd = "python3 -m venv .venv"
    local result = os.execute(cmd)
    
    if result then
        print("  ✓ venv created successfully")
        
        -- Check if pip exists
        local pip_check = os.execute("test -f .venv/bin/pip")
        if pip_check then
            print("  ✓ pip found in venv")
        else
            print("  ✗ pip NOT found in venv")
            return false
        end
    else
        print("  ✗ Failed to create venv")
        return false
    end
    
    os.execute("cd " .. original_dir)
    return true
end

local function test_pip_install(test_dir)
    print("\n[TEST] Package installation with pip")
    
    local original_dir = os.getenv("PWD")
    os.execute("cd " .. test_dir)
    
    -- Test pip upgrade
    local upgrade_cmd = ".venv/bin/pip install --upgrade pip"
    print("  Running: " .. upgrade_cmd)
    local result = os.execute(upgrade_cmd .. " > /dev/null 2>&1")
    
    if result then
        print("  ✓ pip upgraded successfully")
    else
        print("  ✗ pip upgrade failed")
        -- Try to see the error
        os.execute(upgrade_cmd)
        return false
    end
    
    -- Test installing a simple package
    local install_cmd = ".venv/bin/pip install requests"
    print("  Running: " .. install_cmd)
    result = os.execute(install_cmd .. " > /dev/null 2>&1")
    
    if result then
        print("  ✓ Test package installed successfully")
    else
        print("  ✗ Package installation failed")
        -- Try to see the error
        os.execute(install_cmd)
        return false
    end
    
    os.execute("cd " .. original_dir)
    return true
end

local function test_uv_install(test_dir)
    print("\n[TEST] Package installation with uv")
    
    -- Check if uv is available
    local has_uv = os.execute("which uv > /dev/null 2>&1")
    if not has_uv then
        print("  ⚠ uv not installed, skipping test")
        return true
    end
    
    local original_dir = os.getenv("PWD")
    os.execute("cd " .. test_dir)
    
    -- Create venv with uv
    os.execute("rm -rf .venv")  -- Clean up first
    local cmd = "uv venv .venv"
    print("  Running: " .. cmd)
    local result = os.execute(cmd .. " > /dev/null 2>&1")
    
    if result then
        print("  ✓ venv created with uv")
    else
        print("  ✗ Failed to create venv with uv")
        return false
    end
    
    -- Install with uv
    local install_cmd = "uv pip install requests"
    print("  Running: " .. install_cmd)
    result = os.execute("source .venv/bin/activate && " .. install_cmd .. " > /dev/null 2>&1")
    
    if result then
        print("  ✓ Package installed with uv")
    else
        print("  ✗ Failed to install with uv")
        return false
    end
    
    os.execute("cd " .. original_dir)
    return true
end

local function test_essential_packages(test_dir)
    print("\n[TEST] Essential packages installation")
    
    local original_dir = os.getenv("PWD")
    os.execute("cd " .. test_dir)
    
    -- Install all essentials
    local essentials = { "pynvim", "ipykernel", "jupyter_client", "jupytext" }
    local packages_str = table.concat(essentials, " ")
    local cmd = ".venv/bin/pip install " .. packages_str
    
    print("  Installing: " .. packages_str)
    local result = os.execute(cmd .. " > /dev/null 2>&1")
    
    if not result then
        print("  ✗ Failed to install essentials")
        print("  Trying to see the error:")
        os.execute(cmd)
        return false
    end
    
    -- Verify each package
    for _, pkg in ipairs(essentials) do
        local import_name = pkg
        if pkg == "jupyter_client" then
            import_name = "jupyter_client"
        end
        
        local check_cmd = string.format(".venv/bin/python -c 'import %s' 2>/dev/null", import_name)
        local check_result = os.execute(check_cmd)
        
        if check_result then
            print("  ✓ " .. pkg .. " installed and importable")
        else
            print("  ✗ " .. pkg .. " failed to import")
            return false
        end
    end
    
    os.execute("cd " .. original_dir)
    return true
end

-- Run all tests
local function run_tests()
    print("=== Pyworks Integration Tests ===")
    print("Testing actual installation processes...")
    
    local test_dir = setup_test_environment()
    print("\nTest directory: " .. test_dir)
    
    local tests = {
        { name = "venv creation", fn = test_venv_creation },
        { name = "pip install", fn = test_pip_install },
        { name = "uv install", fn = test_uv_install },
        { name = "essential packages", fn = test_essential_packages },
    }
    
    local passed = 0
    local failed = 0
    
    for _, test in ipairs(tests) do
        local ok, result = pcall(test.fn, test_dir)
        if ok and result then
            passed = passed + 1
        else
            failed = failed + 1
            print("  Test '" .. test.name .. "' failed: " .. tostring(result))
        end
    end
    
    -- Cleanup
    cleanup_test_environment(test_dir)
    
    print("\n=== Results ===")
    print(string.format("Passed: %d, Failed: %d", passed, failed))
    
    if failed > 0 then
        print("\n⚠️  Some tests failed. This explains why the plugin isn't working properly.")
        print("The issues found here need to be fixed in the actual implementation.")
    else
        print("\n✅ All tests passed! The installation process should work.")
    end
end

-- Run if executed directly
if arg and arg[0]:match("integration_test.lua") then
    run_tests()
else
    print("Run this file directly: lua tests/integration_test.lua")
end