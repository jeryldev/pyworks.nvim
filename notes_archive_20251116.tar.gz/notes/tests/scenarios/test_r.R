# Test R file for pyworks.nvim
# This file tests R package detection and IRkernel setup

# Data manipulation packages
library(tidyverse)
library(dplyr)
library(tidyr)
library(readr)

# Plotting packages
library(ggplot2)
library(plotly)

# Statistics packages
library(stats)
library(lme4)

# Machine learning
library(caret)
library(randomForest)

# Alternative loading method
require(shiny)
require(lubridate)

# Create test data
set.seed(42)
data <- data.frame(
  x = 1:100,
  y = rnorm(100),
  z = runif(100),
  category = sample(c("A", "B", "C"), 100, replace = TRUE)
)

# Basic plot with ggplot2
p <- ggplot(data, aes(x = x, y = y, color = category)) +
  geom_point() +
  theme_minimal() +
  labs(title = "R Test Plot",
       x = "X axis",
       y = "Y axis")

print(p)

# Function definition
analyze_data <- function(df) {
  # Test function for data analysis in R
  summary_stats <- summary(df)
  return(summary_stats)
}

# Data manipulation with dplyr
result <- data %>%
  group_by(category) %>%
  summarise(
    mean_y = mean(y),
    sd_y = sd(y),
    count = n()
  )

# Statistical test
t_test <- t.test(y ~ category, data = filter(data, category %in% c("A", "B")))

# Main execution
cat("R test file loaded successfully\n")
print(analyze_data(data))
print(result)
print(t_test)