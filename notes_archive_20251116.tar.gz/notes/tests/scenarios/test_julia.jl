# Test Julia file for pyworks.nvim
# This file tests Julia package detection and IJulia kernel setup

# Data manipulation packages
using DataFrames
using CSV
using Statistics

# Plotting packages
using Plots
using StatsPlots

# Scientific computing
using LinearAlgebra
using DifferentialEquations
using Flux  # Machine learning

# Import statement (different from using)
import Random
import Distributions

# Test data creation
data = DataFrame(
    x = 1:100,
    y = rand(100),
    z = randn(100)
)

# Plotting test
plot(data.x, data.y, 
     title = "Julia Test Plot",
     xlabel = "X axis",
     ylabel = "Y axis",
     legend = false)

# Function definition
function analyze_data(df::DataFrame)
    """Test function for data analysis in Julia."""
    return describe(df)
end

# Matrix operations
A = rand(10, 10)
B = rand(10, 10)
C = A * B

# Differential equation example
function lorenz!(du, u, p, t)
    σ, ρ, β = p
    du[1] = σ * (u[2] - u[1])
    du[2] = u[1] * (ρ - u[3]) - u[2]
    du[3] = u[1] * u[2] - β * u[3]
end

# Main execution
println("Julia test file loaded successfully")
result = analyze_data(data)
println(result)

# Test for Project.toml detection
# If Project.toml exists in folder, should activate project environment