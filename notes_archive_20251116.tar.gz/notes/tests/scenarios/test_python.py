# Test Python file for pyworks.nvim
# This file tests package detection and environment setup

# Standard library imports
import os
import sys
from pathlib import Path

# Data science imports (should trigger missing package detection)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Machine learning imports
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# Web/API imports
import requests
import fastapi

# Test compatibility issues (Python 3.12+)
try:
    import tensorflow as tf  # Should warn on Python 3.12+
except ImportError:
    pass

# Package name mapping tests
from PIL import Image  # Should map to Pillow
import cv2  # Should map to opencv-python
from bs4 import BeautifulSoup  # Should map to beautifulsoup4

# Jupyter cell markers (should trigger kernel initialization)
# %%
print("This is a Jupyter cell")
data = pd.DataFrame({
    'x': np.random.randn(100),
    'y': np.random.randn(100)
})

# %%
# Plotting test
plt.figure(figsize=(10, 6))
plt.scatter(data['x'], data['y'])
plt.title('Test Plot')
plt.show()

# Function to test
def analyze_data(df):
    """Test function for data analysis."""
    return df.describe()

if __name__ == "__main__":
    print("Test file loaded successfully")
    result = analyze_data(data)
    print(result)