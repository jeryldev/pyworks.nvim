-- Test helpers for pyworks.nvim tests

local M = {}

-- Setup a Python environment with common packages
function M.setup_python_environment(dir)
  local old_dir = vim.fn.getcwd()
  vim.fn.chdir(dir)
  
  -- Create venv
  vim.fn.system("python -m venv .venv")
  
  -- Install essential packages (mocked for speed in tests)
  local venv_pip = dir .. "/.venv/bin/pip"
  vim.fn.system(venv_pip .. " install pynvim ipykernel jupyter_client")
  
  vim.fn.chdir(old_dir)
end

-- Setup a Julia environment
function M.setup_julia_environment(dir)
  -- This would typically install IJulia
  -- Mocked for testing
  return true
end

-- Setup an R environment  
function M.setup_r_environment(dir)
  -- This would typically install IRkernel
  -- Mocked for testing
  return true
end

-- Create a test notebook with metadata
function M.create_test_notebook(path, language)
  language = language or "python"
  
  local notebook = {
    cells = {
      {
        cell_type = "code",
        execution_count = nil,
        metadata = {},
        outputs = {},
        source = {
          "# Test cell\n",
          "import numpy as np\n"
        }
      }
    },
    metadata = {
      kernelspec = {
        display_name = language == "python" and "Python 3" or language,
        language = language,
        name = language == "python" and "python3" or language
      },
      language_info = {
        name = language
      }
    },
    nbformat = 4,
    nbformat_minor = 5
  }
  
  local file = io.open(path, "w")
  if file then
    file:write(vim.json.encode(notebook))
    file:close()
  end
end

-- Mock slow operations for faster testing
function M.mock_slow_operations()
  local original_system = vim.fn.system
  vim.fn.system = function(cmd)
    -- Mock package installations
    if cmd:match("pip install") then
      return ""  -- Success
    elseif cmd:match("Pkg.add") then
      return ""  -- Success
    elseif cmd:match("install.packages") then
      return ""  -- Success
    else
      return original_system(cmd)
    end
  end
end

-- Restore original functions
function M.restore_functions()
  -- Would restore any mocked functions
end

-- Wait for async operations with timeout
function M.wait_for(condition_fn, timeout_ms)
  timeout_ms = timeout_ms or 5000
  local start = vim.loop.hrtime()
  
  while not condition_fn() do
    vim.wait(10)
    local elapsed = (vim.loop.hrtime() - start) / 1000000
    if elapsed > timeout_ms then
      return false
    end
  end
  
  return true
end

-- Check if a package is installed in venv
function M.is_package_installed(package, venv_path)
  venv_path = venv_path or ".venv"
  local pip_path = venv_path .. "/bin/pip"
  local result = vim.fn.system(pip_path .. " show " .. package .. " 2>/dev/null")
  return vim.v.shell_error == 0
end

-- Clear all caches
function M.clear_caches()
  local cache = require('pyworks.cache')
  if cache and cache.clear then
    cache.clear()
  end
end

-- Capture notifications
function M.capture_notifications()
  local notifications = {}
  local original_notify = vim.notify
  
  vim.notify = function(msg, level)
    table.insert(notifications, {
      message = msg,
      level = level,
      time = vim.loop.hrtime()
    })
  end
  
  return notifications, original_notify
end

-- Restore notifications
function M.restore_notifications(original_notify)
  vim.notify = original_notify
end

return M