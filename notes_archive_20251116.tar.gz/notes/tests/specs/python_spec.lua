-- Test specification for Python file handling
-- Requires plenary.nvim

local helpers = require('tests.helpers')
local pyworks = require('pyworks')

describe("Python file handling", function()
  local test_file = "tests/scenarios/test_python.py"
  local temp_dir
  
  before_each(function()
    -- Create temporary directory for test
    temp_dir = vim.fn.tempname()
    vim.fn.mkdir(temp_dir, 'p')
    vim.fn.chdir(temp_dir)
    
    -- Copy test file to temp directory
    vim.fn.system(string.format("cp %s %s/test.py", test_file, temp_dir))
  end)
  
  after_each(function()
    -- Clean up
    vim.fn.system(string.format("rm -rf %s", temp_dir))
  end)
  
  describe("First time access", function()
    it("should create .venv if it doesn't exist", function()
      -- Open Python file
      vim.cmd("edit test.py")
      
      -- Wait for autocmds to trigger
      vim.wait(100)
      
      -- Check that .venv was created
      assert.is_true(vim.fn.isdirectory('.venv') == 1)
    end)
    
    it("should detect missing packages", function()
      -- Open Python file
      vim.cmd("edit test.py")
      
      -- Wait for package detection
      vim.wait(2000)
      
      -- Check that missing packages were detected
      local detector = require('pyworks.package-detector')
      local result = detector.analyze_buffer()
      
      assert.is_not_nil(result.missing)
      assert.is_true(vim.tbl_contains(result.missing, 'numpy'))
      assert.is_true(vim.tbl_contains(result.missing, 'pandas'))
    end)
    
    it("should map package names correctly", function()
      local detector = require('pyworks.package-detector')
      
      -- Test package name mappings
      assert.equals(detector.map_import_to_package('sklearn'), 'scikit-learn')
      assert.equals(detector.map_import_to_package('PIL'), 'Pillow')
      assert.equals(detector.map_import_to_package('cv2'), 'opencv-python')
      assert.equals(detector.map_import_to_package('bs4'), 'beautifulsoup4')
    end)
    
    it("should install essential packages automatically", function()
      -- Open Python file
      vim.cmd("edit test.py")
      
      -- Wait for setup
      vim.wait(5000)
      
      -- Check that essential packages are installed
      local utils = require('pyworks.utils')
      local python_path = utils.get_python_path()
      
      -- Check pynvim
      local pynvim_check = vim.fn.system(python_path .. " -c 'import pynvim'")
      assert.equals(vim.v.shell_error, 0)
      
      -- Check ipykernel
      local ipykernel_check = vim.fn.system(python_path .. " -c 'import ipykernel'")
      assert.equals(vim.v.shell_error, 0)
    end)
    
    it("should show notifications for missing packages", function()
      -- Mock vim.notify to capture messages
      local notifications = {}
      local original_notify = vim.notify
      vim.notify = function(msg, level)
        table.insert(notifications, {message = msg, level = level})
      end
      
      -- Open Python file
      vim.cmd("edit test.py")
      vim.wait(2000)
      
      -- Restore original notify
      vim.notify = original_notify
      
      -- Check that appropriate notifications were shown
      local found_missing = false
      for _, notif in ipairs(notifications) do
        if notif.message:match("Missing packages") then
          found_missing = true
          break
        end
      end
      
      assert.is_true(found_missing)
    end)
  end)
  
  describe("Second time access", function()
    before_each(function()
      -- Setup environment first
      helpers.setup_python_environment(temp_dir)
    end)
    
    it("should be completely silent when all packages installed", function()
      -- Track notifications
      local notifications = {}
      local original_notify = vim.notify
      vim.notify = function(msg, level)
        -- Ignore debug messages
        if level ~= vim.log.levels.DEBUG then
          table.insert(notifications, {message = msg, level = level})
        end
      end
      
      -- Open Python file
      vim.cmd("edit test.py")
      vim.wait(500)
      
      -- Restore original notify
      vim.notify = original_notify
      
      -- Should have no notifications (silent)
      assert.equals(#notifications, 0)
    end)
    
    it("should use cached results for fast startup", function()
      local start_time = vim.loop.hrtime()
      
      -- Open Python file
      vim.cmd("edit test.py")
      vim.wait(100)
      
      local end_time = vim.loop.hrtime()
      local elapsed_ms = (end_time - start_time) / 1000000
      
      -- Should be ready in less than 500ms
      assert.is_true(elapsed_ms < 500)
    end)
  end)
  
  describe("Package installation", function()
    it("should install packages when user presses <leader>pi", function()
      -- Open Python file
      vim.cmd("edit test.py")
      vim.wait(2000)
      
      -- Simulate pressing <leader>pi
      vim.api.nvim_feedkeys(vim.api.nvim_replace_termcodes("<leader>pi", true, false, true), 'n', false)
      
      -- Wait for installation (mocked for speed)
      vim.wait(1000)
      
      -- Check that installation was triggered
      local config = require('pyworks.config')
      local jobs = config.get_state('active_jobs') or {}
      
      -- Should have or have had an installation job
      assert.is_true(#jobs > 0 or config.get_state('last_install_time') ~= nil)
    end)
    
    it("should handle compatibility warnings", function()
      -- Set Python version to 3.12
      vim.g.python3_host_prog = '/usr/bin/python3.12'
      
      -- Open file with tensorflow import
      vim.cmd("edit test.py")
      vim.wait(2000)
      
      -- Check for compatibility warning
      local detector = require('pyworks.package-detector')
      local result = detector.analyze_buffer()
      
      local has_tensorflow_warning = false
      for _, issue in ipairs(result.compatibility or {}) do
        if issue.package == 'tensorflow' then
          has_tensorflow_warning = true
          break
        end
      end
      
      assert.is_true(has_tensorflow_warning)
    end)
  end)
  
  describe("Virtual environment management", function()
    it("should respect use_uv setting", function()
      -- Configure to use uv
      pyworks.setup({
        python = {
          use_uv = true
        }
      })
      
      -- Mock command existence check
      local original_executable = vim.fn.executable
      vim.fn.executable = function(cmd)
        if cmd == 'uv' then
          return 1
        end
        return original_executable(cmd)
      end
      
      -- Open Python file
      vim.cmd("edit test.py")
      vim.wait(1000)
      
      -- Restore original
      vim.fn.executable = original_executable
      
      -- Check that uv was used (would need to check actual commands)
      -- This is a simplified test
      assert.is_true(true)
    end)
    
    it("should respect existing venv package manager", function()
      -- Create venv with pip
      vim.fn.system("python -m venv .venv")
      
      -- Open Python file
      vim.cmd("edit test.py")
      vim.wait(1000)
      
      -- Should use pip, not uv (even if use_uv = true)
      local utils = require('pyworks.utils')
      assert.is_false(vim.fn.filereadable('.venv/bin/uv') == 1)
    end)
  end)
end)