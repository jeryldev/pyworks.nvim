# %% Test cell 1
print("Hello from cell 1")
x = 10
y = 20

# %% Test cell 2  
print(f"x + y = {x + y}")
result = x * y
print(f"x * y = {result}")

# %% Test cell 3
import numpy as np
arr = np.array([1, 2, 3, 4, 5])
print(f"Array: {arr}")
print(f"Sum: {arr.sum()}")

# Instructions to test:
# 1. Open this file
# 2. Press <leader>jr to select a cell
# 3. While still in visual mode, press <leader>jv to run it
# 
# Alternative:
# 1. Manually select lines with V (visual line mode)
# 2. Press <leader>jv to run selection