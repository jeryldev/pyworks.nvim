# 🎯 Pyworks.nvim - The 6 Core Scenarios

## Zero-Configuration Workflow for All Scenarios

Pyworks.nvim provides a **completely automatic** experience for these 6 scenarios:

| # | File Type | Extension | What Happens Automatically |
|---|-----------|-----------|---------------------------|
| 1 | Python File | `.py` | Creates .venv → Installs essentials → Detects packages → Molten ready |
| 2 | Julia File | `.jl` | Checks Julia → Ensures IJulia → Detects packages → Molten ready |
| 3 | R File | `.R` | Checks R → Ensures IRkernel → Detects packages → Molten ready |
| 4 | Python Notebook | `.ipynb` | Jupytext converts → Creates .venv → Detects packages → Molten ready |
| 5 | Julia Notebook | `.ipynb` | Jupytext converts → Ensures IJulia → Detects packages → Molten ready |
| 6 | R Notebook | `.ipynb` | Jupytext converts → Ensures IRkernel → Detects packages → Molten ready |

---

## Scenario 1: Python File (.py)

### First Time Opening
```
Open test.py
  ↓
✅ Pyworks creates .venv (using uv or pip based on config)
  ↓
✅ Installs essentials: pynvim, ipykernel, jupyter_client, jupytext
  ↓
✅ Scans file for imports (numpy, pandas, matplotlib, etc.)
  ↓
✅ Shows missing packages only if any found
  ↓
✅ AUTO-INITIALIZES Molten with python3 kernel (200ms)
  ↓
✅ Shows: "Molten ready with python3 kernel - Use <leader>jl to run code"
  ↓
READY! Start coding immediately!
```

### Second Time Opening
```
Open test.py
  ↓
Everything cached, instant ready (< 0.5s)
  ↓
Silent - no notifications
```

### Keymaps Available
- `<leader>jl` - Run current line
- `<leader>jv` - Run visual selection
- `<leader>jr` - Select cell/entire file
- `<leader>pi` - Install missing packages
- `]j` / `[j` - Navigate cells (if using # %% markers)

---

## Scenario 2: Julia File (.jl)

### First Time Opening
```
Open test.jl
  ↓
✅ Checks if Julia is installed
  ↓
✅ Prompts once for IJulia kernel if not installed
  ↓
✅ Activates Project.toml if exists
  ↓
✅ Scans for using/import statements
  ↓
✅ Shows missing packages only if any found
  ↓
✅ AUTO-INITIALIZES Molten with julia kernel (200ms)
  ↓
✅ Shows: "Molten ready with julia kernel - Use <leader>jl to run code"
  ↓
READY! Start coding immediately!
```

### Package Detection
- Detects: `using DataFrames`, `import CSV`, etc.
- Respects Project.toml environment
- Installs via Pkg.add()

---

## Scenario 3: R File (.R)

### First Time Opening
```
Open test.R
  ↓
✅ Checks if R is installed
  ↓
✅ Prompts once for IRkernel if not installed
  ↓
✅ Scans for library() and require() calls
  ↓
✅ Shows missing packages only if any found
  ↓
✅ AUTO-INITIALIZES Molten with ir kernel (200ms)
  ↓
✅ Shows: "Molten ready with ir kernel - Use <leader>jl to run code"
  ↓
READY! Start coding immediately!
```

### Package Detection
- Detects: `library(ggplot2)`, `require(dplyr)`, etc.
- Respects renv if present
- Installs via install.packages()

---

## Scenario 4: Python Notebook (.ipynb)

### First Time Opening
```
Open analysis.ipynb
  ↓
✅ Pyworks ensures jupytext is installed (BufReadPre)
  ↓
✅ Creates .venv if missing
  ↓
✅ Jupytext converts to readable format with # %% cells
  ↓
✅ Pyworks detects it's Python from metadata
  ↓
✅ Scans all code cells for imports
  ↓
✅ Shows missing packages only if any found
  ↓
✅ AUTO-INITIALIZES Molten with python3 kernel (200ms)
  ↓
✅ Shows: "Molten ready with python3 kernel - Use <leader>jl to run code"
  ↓
READY! Navigate cells with ]j/[j, execute with <leader>jv
```

### Special Features
- Converts JSON to readable percent format
- Preserves cell structure with # %% markers
- Auto-saves back to .ipynb format
- Shows plots inline with image.nvim

---

## Scenario 5: Julia Notebook (.ipynb)

### First Time Opening
```
Open julia_analysis.ipynb
  ↓
✅ Pyworks ensures jupytext is installed
  ↓
✅ Jupytext converts to readable .jl format
  ↓
✅ Detects Julia language from metadata
  ↓
✅ Ensures IJulia kernel is available
  ↓
✅ Scans all cells for using/import
  ↓
✅ Shows missing packages only if any found
  ↓
✅ AUTO-INITIALIZES Molten with julia kernel (200ms)
  ↓
✅ Shows: "Molten ready with julia kernel - Use <leader>jl to run code"
  ↓
READY! Navigate cells with ]j/[j, execute with <leader>jv
```

### Language Detection
- Reads notebook metadata.kernelspec.language
- Falls back to file extension hints
- Defaults to Python if uncertain

---

## Scenario 6: R Notebook (.ipynb)

### First Time Opening
```
Open r_stats.ipynb
  ↓
✅ Pyworks ensures jupytext is installed
  ↓
✅ Jupytext converts to readable .R format
  ↓
✅ Detects R language from metadata
  ↓
✅ Ensures IRkernel is available
  ↓
✅ Scans all cells for library() calls
  ↓
✅ Shows missing packages only if any found
  ↓
✅ AUTO-INITIALIZES Molten with ir kernel (200ms)
  ↓
✅ Shows: "Molten ready with ir kernel - Use <leader>jl to run code"
  ↓
READY! Navigate cells with ]j/[j, execute with <leader>jv
```

---

## 🎮 Universal Keymaps (All 6 Scenarios)

| Keymap | Action | Description |
|--------|--------|-------------|
| `<leader>jl` | Run line | Execute current line and move to next |
| `<leader>jv` | Run visual | Execute visually highlighted selection |
| `<leader>jr` | Select cell | Visually highlight current cell or entire file |
| `<leader>jc` | Re-run cell | Re-evaluate current cell |
| `<leader>jd` | Delete output | Clear cell output |
| `<leader>jo` | Toggle output | Show/hide output window |
| `<leader>je` | Enter output | Focus output window |
| `<leader>pi` | Install packages | Install detected missing packages |
| `]j` | Next cell | Jump to next # %% marker |
| `[j` | Previous cell | Jump to previous # %% marker |
| `<leader>mi` | Init kernel | Manually initialize Molten (rarely needed) |

---

## 🚀 The Magic

**No configuration required!** Just:

1. Install pyworks.nvim
2. Open ANY of the 6 file types
3. Everything works automatically

**No need to:**
- ❌ Run :PyworksSetup
- ❌ Configure virtual environments
- ❌ Install jupytext manually
- ❌ Initialize Molten manually
- ❌ Set up kernels manually
- ❌ Install packages manually (except with <leader>pi confirmation)

---

## 📊 Performance Guarantees

| Metric | First Time | Subsequent |
|--------|------------|------------|
| Time to ready | < 30s | < 0.5s |
| User actions | 0-1 (package install) | 0 |
| Notifications | Progress + missing packages | None (silent) |
| Cache hit rate | 0% | > 90% |

---

## 🔧 Behind the Scenes

### Order of Operations

1. **BufReadPre** (for .ipynb)
   - Ensure jupytext installed
   - Add .venv/bin to PATH

2. **BufReadCmd** (jupytext.nvim)
   - Convert notebook to readable format

3. **BufReadPost** (pyworks)
   - Detect file type and language
   - Set up environment
   - Scan for packages
   - Initialize keymaps

4. **Deferred** (1 second)
   - Auto-initialize Molten kernel

### Smart Caching
- Virtual environment status (30s TTL)
- Installed packages list (5min TTL)
- Kernel availability (1min TTL)
- Notebook metadata (2min TTL)

### Package Manager Detection
- Detects uv vs pip automatically
- Checks pyvenv.cfg for "uv ="
- Falls back appropriately

---

## 🎯 Success Criteria

✅ **All 6 scenarios work with ZERO configuration**
✅ **Automatic environment setup**
✅ **Automatic package detection**
✅ **Automatic kernel initialization**
✅ **Consistent keymaps across all scenarios**
✅ **Fast and silent when everything is ready**