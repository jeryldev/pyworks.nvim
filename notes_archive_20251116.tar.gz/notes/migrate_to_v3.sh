#!/bin/bash

# Migration script for pyworks.nvim v3.0.0
# This script archives legacy files and prepares the new structure

echo "=== Pyworks.nvim v3.0.0 Migration ==="
echo ""

# Create backup directory
BACKUP_DIR="legacy_backup_$(date +%Y%m%d_%H%M%S)"
echo "Creating backup directory: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"

# Backup legacy files
echo "Backing up legacy files..."
legacy_files=(
    "lua/pyworks/autocmds.lua"
    "lua/pyworks/auto-install.lua"
    "lua/pyworks/cell-navigation.lua"
    "lua/pyworks/check-dependencies.lua"
    "lua/pyworks/commands.lua"
    "lua/pyworks/config.lua"
    "lua/pyworks/diagnostics.lua"
    "lua/pyworks/jupytext.lua"
    "lua/pyworks/kernel-manager.lua"
    "lua/pyworks/molten-safety.lua"
    "lua/pyworks/molten.lua"
    "lua/pyworks/notebook-essentials.lua"
    "lua/pyworks/notebooks.lua"
    "lua/pyworks/package-detector.lua"
    "lua/pyworks/setup.lua"
    "lua/pyworks/utils.lua"
    "lua/pyworks/init_old.lua"
    "lua/pyworks/init_new.lua"
)

for file in "${legacy_files[@]}"; do
    if [ -f "$file" ]; then
        echo "  Backing up: $file"
        cp "$file" "$BACKUP_DIR/"
    fi
done

# Archive legacy files
echo ""
echo "Archiving legacy files..."
for file in "${legacy_files[@]}"; do
    if [ -f "$file" ]; then
        echo "  Removing: $file"
        rm "$file"
    fi
done

# Clean up empty init_new.lua
if [ -f "lua/pyworks/init_new.lua" ]; then
    rm "lua/pyworks/init_new.lua"
fi

# Keep essential utility files if they exist
echo ""
echo "Preserving essential utilities..."
if [ -f "$BACKUP_DIR/utils.lua" ]; then
    echo "  Restoring utils.lua for compatibility"
    cp "$BACKUP_DIR/utils.lua" "lua/pyworks/utils.lua"
fi

if [ -f "$BACKUP_DIR/config.lua" ]; then
    echo "  Creating minimal config.lua for compatibility"
    cat > "lua/pyworks/config.lua" << 'EOF'
-- Minimal config module for backward compatibility
-- The real configuration is now in init.lua

local M = {}

function M.get_state(key)
    local state = require("pyworks.core.state")
    return state.get(key)
end

function M.set_state(key, value)
    local state = require("pyworks.core.state")
    state.set(key, value)
end

return M
EOF
fi

# Create README for the backup
cat > "$BACKUP_DIR/README.md" << 'EOF'
# Legacy Backup - Pyworks.nvim v2.x

This directory contains the legacy files from pyworks.nvim v2.x.
These files have been replaced by the new modular architecture in v3.0.0.

## Migration Notes

The new architecture provides:
- Zero-configuration experience
- Modular language support
- Better performance with caching
- Cleaner codebase organization

## File Mapping

- `autocmds.lua` → Split into language modules and detector
- `package-detector.lua` → `core/packages.lua`
- `jupytext.lua` → `notebook/jupytext.lua`
- `notebook-essentials.lua` → Integrated into language modules
- `molten.lua` → Will be added to `integrations/` if needed

If you need to reference the old implementation, these files are preserved here.
EOF

echo ""
echo "=== Migration Complete ==="
echo ""
echo "✓ Legacy files backed up to: $BACKUP_DIR"
echo "✓ New modular structure is ready"
echo ""
echo "Next steps:"
echo "1. Test the new setup with: nvim tests/scenarios/test_python.py"
echo "2. Run :checkhealth pyworks"
echo "3. If everything works, you can remove the backup directory"
echo ""
echo "If you encounter issues, restore from backup with:"
echo "  cp $BACKUP_DIR/* lua/pyworks/"