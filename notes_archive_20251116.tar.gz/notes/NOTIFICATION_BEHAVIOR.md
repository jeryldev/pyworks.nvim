# Pyworks.nvim Notification Behavior

## Core Principle: Silent When Ready

Pyworks follows these notification rules across all 6 scenarios:

### 🔕 When to be SILENT

1. **No missing packages** - If all imports/using/library packages are installed
2. **Kernel already installed** - IJulia/IRkernel already present
3. **Environment ready** - After first-time setup
4. **Subsequent file access** - Everything cached and ready

### 📢 When to NOTIFY

1. **Missing packages detected** - Shows list with `<leader>pi` instruction
2. **First-time kernel setup** - One-time prompt for IJulia/IRkernel
3. **Installation progress** - While packages are installing
4. **Installation complete** - ONLY after actual completion (using on_exit)
5. **Errors** - Any installation or detection failures

### ✅ Expected Behavior by Scenario

#### Python File (.py) or Notebook (.ipynb)
- **First time with missing packages**: Shows missing packages list
- **First time without missing packages**: SILENT
- **Subsequent access**: ALWAYS SILENT

#### Julia File (.jl) or Notebook (.ipynb)
- **First time without IJulia**: Prompts once to install IJulia
- **First time with IJulia, missing packages**: Shows missing packages
- **First time with IJulia, no missing packages**: SILENT
- **Subsequent access**: ALWAYS SILENT

#### R File (.R) or Notebook (.ipynb)
- **First time without IRkernel**: Prompts once to install IRkernel
- **First time with IRkernel, missing packages**: Shows missing packages
- **First time with IRkernel, no missing packages**: SILENT
- **Subsequent access**: ALWAYS SILENT

### 🔧 Implementation Details

1. **Package Detection**
   ```lua
   if #missing > 0 then
       notifications.notify_missing_packages(missing, language)
   else
       -- SILENT - no notification
   end
   ```

2. **Kernel Check**
   ```lua
   if M.has_ijulia() then
       return true  -- Already installed, SILENT
   end
   ```

3. **Installation Completion**
   ```lua
   on_exit = function(_, code)
       if code == 0 then
           -- Only NOW show success
           notifications.progress_finish("packages", "Installed successfully")
       end
   end
   ```

### 🚫 Common Issues to Avoid

1. **Don't show "ready" when already ready** - No "all packages installed" if none were missing
2. **Don't re-prompt for kernels** - Track if already prompted with state
3. **Don't show premature success** - Wait for on_exit callback
4. **Don't notify on every file open** - Use caching and first-time checks

### 📊 Notification Decision Tree

```
File Opened
    ↓
Has kernel? → No → Prompt once (then never again)
    ↓ Yes
Check packages
    ↓
Missing? → Yes → Show list with <leader>pi
    ↓ No
SILENT (no notifications)
```

### 🎯 End Goal

**Perfect silence when everything is ready** - The best notification is no notification when there's nothing the user needs to do.