# IPython configuration for inline matplotlib
# This should be run at the start of your IPython/Jupyter session

# Get the IPython instance
try:
    from IPython import get_ipython
    ipython = get_ipython()
    
    if ipython is not None:
        # Configure matplotlib to use inline backend
        ipython.run_line_magic('matplotlib', 'inline')
        
        # Optional: Configure figure format for better quality
        ipython.run_line_magic('config', "InlineBackend.figure_format = 'retina'")
        
        print("Matplotlib configured for inline display")
except:
    # Not in IPython environment, use Agg backend
    import matplotlib
    matplotlib.use('Agg')
    print("Using Agg backend for matplotlib")