-- pyworks.nvim - Python environments tailored for Neovim
-- Version: 2.0.0
-- 
-- Multi-language Jupyter kernel support for Python, Julia, and R
-- Smart package detection with compatibility handling
-- Consistent workflow across all file types
--
-- Main module

local M = {}
local config = require("pyworks.config")

-- Setup function
function M.setup(opts)
	-- Prevent multiple setup calls
	if vim.g.pyworks_setup_complete then
		return
	end
	-- Setup jupytext metadata fixing
	require("pyworks.jupytext").setup()

	-- Set Python host if not already set
	if not vim.g.python3_host_prog then
		-- Try to find the best Python executable
		local python_candidates = {
			vim.fn.getcwd() .. "/.venv/bin/python3",
			vim.fn.getcwd() .. "/.venv/bin/python",
			vim.fn.exepath("python3"),
			vim.fn.exepath("python"),
		}

		for _, python_path in ipairs(python_candidates) do
			if vim.fn.executable(python_path) == 1 then
				vim.g.python3_host_prog = python_path
				break
			end
		end
	end
	
	-- Verify Python host and pynvim installation (only once per session)
	if not vim.g.pyworks_python_host_checked then
		vim.g.pyworks_python_host_checked = true
		vim.defer_fn(function()
			local python_host = vim.g.python3_host_prog
			if python_host then
				-- Check if pynvim is installed
				local check_cmd = python_host .. " -c 'import pynvim' 2>&1"
				local result = vim.fn.system(check_cmd)
				if vim.v.shell_error ~= 0 then
					-- Try to fix it automatically (only once)
					if not vim.g.pyworks_python_host_fix_attempted then
						vim.g.pyworks_python_host_fix_attempted = true
						local utils = require("pyworks.utils")
						utils.notify("Python host issue detected - attempting to fix...", vim.log.levels.WARN)
						
						-- Install pynvim in the virtual environment
						local venv_pip = vim.fn.getcwd() .. "/.venv/bin/pip"
						if vim.fn.executable(venv_pip) == 1 then
							vim.fn.system(venv_pip .. " install --upgrade pynvim neovim 2>&1")
							utils.notify("Installed pynvim - restart Neovim to complete setup", vim.log.levels.INFO)
						end
					end
				end
			end
		end, 1000) -- Delay to let Neovim fully initialize
	end

	-- Validate and setup configuration
	if opts then
		local ok, errors = config.validate_config(opts)
		if not ok then
			vim.notify("pyworks.nvim: Invalid configuration:\n" .. table.concat(errors, "\n"), vim.log.levels.ERROR)
			return
		end
	end

	-- Setup configuration
	M.config = config.setup(opts)

	-- Load submodules
	require("pyworks.commands").setup()
	require("pyworks.autocmds").setup(M.config)
	require("pyworks.cell-navigation").setup()

	-- Create user commands
	require("pyworks.commands").create_commands()

	-- Set up Molten keymappings (always set them up, they'll check for Molten availability)
	local molten = require("pyworks.molten")

	-- Core Molten keymappings
	vim.keymap.set("n", "<leader>ji", function()
		molten.init_kernel()
	end, { desc = "[J]upyter [I]nitialize kernel" })
	vim.keymap.set("n", "<leader>jl", function()
		if vim.fn.exists(":MoltenEvaluateLine") == 2 then
			-- Check if kernel is running for this buffer
			if vim.fn.exists("*MoltenRunningKernels") == 1 then
				local buffer_kernels = vim.fn.MoltenRunningKernels(true) or {}
				if #buffer_kernels == 0 then
					-- No kernel running, auto-initialize based on file type
					local ft = vim.bo.filetype
					if ft == "python" or ft == "julia" or ft == "r" then
						vim.notify("Auto-initializing kernel...", vim.log.levels.INFO)
						molten.init_kernel(true) -- Silent mode
						-- Wait a bit then run the line
						vim.defer_fn(function()
							molten.evaluate_line()
						end, 500)
						return
					end
				end
			end
			molten.evaluate_line()
		else
			vim.notify("Molten not available. Run :PyworksSetup and choose 'Data Science / Notebooks' to install", vim.log.levels.WARN)
			vim.notify("Or add molten-nvim to your plugin config dependencies", vim.log.levels.INFO)
		end
	end, { desc = "[J]upyter evaluate [L]ine" })

	-- Visual mode mapping for running selection (both v and x modes)
	vim.keymap.set(
		{ "v", "x" },
		"<leader>jv",
		":<C-u>MoltenEvaluateVisual<CR>",
		{ desc = "[J]upyter evaluate [V]isual", silent = true }
	)

	-- Also add normal mode mapping that uses the last visual selection
	vim.keymap.set("n", "<leader>jv", function()
		if vim.fn.exists(":MoltenEvaluateVisual") == 2 then
			-- Check if kernel is running for this buffer
			if vim.fn.exists("*MoltenRunningKernels") == 1 then
				local buffer_kernels = vim.fn.MoltenRunningKernels(true) or {}
				if #buffer_kernels == 0 then
					-- No kernel running, auto-initialize based on file type
					local ft = vim.bo.filetype
					if ft == "python" or ft == "julia" or ft == "r" then
						vim.notify("Auto-initializing kernel...", vim.log.levels.INFO)
						molten.init_kernel(true) -- Silent mode
						-- Wait a bit then run the selection
						vim.defer_fn(function()
							vim.cmd("normal! gv")
							vim.cmd("MoltenEvaluateVisual")
						end, 500)
						return
					end
				end
			end
			-- Re-select the last visual selection and run it
			vim.cmd("normal! gv")
			vim.cmd("MoltenEvaluateVisual")
		else
			vim.notify("Molten not available. Run :PyworksSetup and choose 'Data Science / Notebooks' to install", vim.log.levels.WARN)
			vim.notify("Or add molten-nvim to your plugin config dependencies", vim.log.levels.INFO)
		end
	end, { desc = "[J]upyter evaluate last [V]isual selection" })

	vim.keymap.set("n", "<leader>je", function()
		if vim.fn.exists(":MoltenEvaluateOperator") == 2 then
			vim.cmd("MoltenEvaluateOperator")
		else
			vim.notify("Jupyter not initialized. Press <leader>ji first", vim.log.levels.WARN)
		end
	end, { desc = "[J]upyter [E]valuate operator" })

	vim.keymap.set("n", "<leader>jo", function()
		if vim.fn.exists(":MoltenEnterOutput") == 2 then
			vim.cmd("noautocmd MoltenEnterOutput")
		else
			vim.notify("Jupyter not initialized. Press <leader>ji first", vim.log.levels.WARN)
		end
	end, { desc = "[J]upyter [O]pen output" })

	vim.keymap.set("n", "<leader>jh", function()
		if vim.fn.exists(":MoltenHideOutput") == 2 then
			vim.cmd("MoltenHideOutput")
		else
			vim.notify("Jupyter not initialized. Press <leader>ji first", vim.log.levels.WARN)
		end
	end, { desc = "[J]upyter [H]ide output" })

	vim.keymap.set("n", "<leader>jd", function()
		if vim.fn.exists(":MoltenDelete") == 2 then
			vim.cmd("MoltenDelete")
		else
			vim.notify("Jupyter not initialized. Press <leader>ji first", vim.log.levels.WARN)
		end
	end, { desc = "[J]upyter [D]elete cell" })

	vim.keymap.set("n", "<leader>js", function()
		if vim.fn.exists(":MoltenInfo") == 2 then
			vim.cmd("MoltenInfo")
		else
			vim.notify("Jupyter not initialized. Press <leader>ji first", vim.log.levels.WARN)
		end
	end, { desc = "[J]upyter [S]tatus/info" })

	-- Image clearing (if image.nvim is available)
	vim.keymap.set("n", "<leader>jc", function()
		local ok, image = pcall(require, "image")
		if ok then
			image.clear()
		else
			vim.notify("Image support not available", vim.log.levels.WARN)
		end
	end, { desc = "[J]upyter [C]lear images" })
	
	-- Package management keybindings
	vim.keymap.set("n", "<leader>pi", function()
		local detector = require("pyworks.package-detector")
		detector.install_suggested()
	end, { desc = "[P]yworks [I]nstall suggested packages" })
	
	vim.keymap.set("n", "<leader>pa", function()
		vim.cmd("PyworksAnalyzeImports")
	end, { desc = "[P]yworks [A]nalyze imports" })

	-- Mark setup as complete
	config.set_state("setup_completed", true)
	vim.g.pyworks_setup_complete = true
end

-- Expose config for backward compatibility
function M.get_config()
	return config.current
end

return M
