# Legacy Backup - Pyworks.nvim v2.x

This directory contains the legacy files from pyworks.nvim v2.x.
These files have been replaced by the new modular architecture in v3.0.0.

## Migration Notes

The new architecture provides:
- Zero-configuration experience
- Modular language support
- Better performance with caching
- Cleaner codebase organization

## File Mapping

- `autocmds.lua` → Split into language modules and detector
- `package-detector.lua` → `core/packages.lua`
- `jupytext.lua` → `notebook/jupytext.lua`
- `notebook-essentials.lua` → Integrated into language modules
- `molten.lua` → Will be added to `integrations/` if needed

If you need to reference the old implementation, these files are preserved here.
