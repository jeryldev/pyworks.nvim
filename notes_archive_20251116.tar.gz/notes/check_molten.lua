-- Quick check for Molten availability
print("Checking Molten status...")

-- Check if Molten commands exist
local molten_init = vim.fn.exists(":MoltenInit")
local molten_eval = vim.fn.exists(":MoltenEvaluateLine")

print("MoltenInit exists: " .. molten_init .. " (2 = command exists)")
print("MoltenEvaluateLine exists: " .. molten_eval .. " (2 = command exists)")

-- Try to run MoltenStatus
local ok, result = pcall(vim.cmd, "MoltenStatus")
if ok then
    print("MoltenStatus: OK")
else
    print("MoltenStatus error: " .. tostring(result))
end

-- Check our keymaps
local keymaps_ok, keymaps = pcall(require, "pyworks.keymaps")
if keymaps_ok then
    print("Pyworks keymaps module: Loaded")
    
    -- Check if detection works
    local has_molten = vim.fn.exists(":MoltenInit") == 2
    print("Molten detected by keymaps: " .. tostring(has_molten))
else
    print("Pyworks keymaps error: " .. tostring(keymaps))
end

-- List current buffer keymaps for leader j
print("\nCurrent buffer keymaps with <leader>j:")
local keymaps_list = vim.api.nvim_buf_get_keymap(0, "n")
for _, map in ipairs(keymaps_list) do
    if map.lhs:match("<leader>j") then
        print("  " .. map.lhs .. " -> " .. (map.desc or map.rhs))
    end
end