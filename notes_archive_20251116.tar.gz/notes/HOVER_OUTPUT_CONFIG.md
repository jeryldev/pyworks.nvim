# Hover-Based Output Display Configuration

## Overview

Pyworks.nvim is now configured to show Molten outputs only on demand (hover) rather than inline, with support for larger charts and images.

## What Changed

### Molten Configuration
- **Auto-open disabled**: Outputs don't automatically appear below/above cells
- **Virtual text disabled**: No inline text output
- **Larger output windows**: 200x80 characters (was 150x40) for better chart viewing
- **Floating window style**: Rounded borders for better visibility

### Image Configuration
- **Larger image display**: 200x80 max dimensions
- **Better chart/plot viewing**: Increased size limits for data visualizations

## How to Use

### Running Code
1. **Execute cell/line**: `<leader>jl` (line) or `<leader>jv` (visual)
2. Output is generated but **not shown automatically**

### Viewing Output
- **Show output**: `<leader>jo` - Display output window for current cell
- **Hide output**: `<leader>jh` - Hide the output window
- **Enter output**: `<leader>je` - Enter output window to interact/scroll
- **Hover (K)**: Press `K` on a cell to show its output (falls back to LSP hover if no output)

### Benefits
1. **Cleaner workspace**: No cluttered inline outputs
2. **Larger visualizations**: Charts and images display at better resolution
3. **On-demand viewing**: See output only when you need it
4. **Better focus**: Code remains unobstructed

## Keybindings Summary

| Key | Action | Description |
|-----|--------|-------------|
| `<leader>jl` | Run line | Execute current line |
| `<leader>jv` | Run visual | Execute visually highlighted selection |
| `<leader>jr` | Select cell | Visually highlight current cell |
| `<leader>jo` | Show output | Display output window |
| `<leader>jh` | Hide output | Hide output window |
| `<leader>je` | Enter output | Focus output window |
| `K` | Hover output | Show output or LSP docs |
| `<leader>jd` | Delete output | Clear cell output |

## Customization

To revert to inline output display, modify `~/.config/nvim/lua/plugins/pyworks-setup.lua`:

```lua
-- Change these settings in the Molten init function:
vim.g.molten_auto_open_output = true  -- Auto-show output
vim.g.molten_virt_text_output = true  -- Show inline text
```

## Tips

1. **Large DataFrames**: Use `<leader>je` to enter output and scroll
2. **Multiple Plots**: Execute cells individually and use `<leader>jo` to view each
3. **Quick Preview**: Use `K` for quick hover preview without opening persistent window
4. **Clean Session**: Use `<leader>jd` to delete outputs and keep workspace clean