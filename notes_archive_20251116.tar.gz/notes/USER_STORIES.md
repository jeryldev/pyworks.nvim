# Pyworks.nvim User Stories

## 🏗️ Critical Dependencies & Installation Flow

### Crucial Packages by Layer:

#### Layer 1: Neovim Integration (CRITICAL)
- **pynvim** - Required for Python-Neovim communication
- **neovim** (Python package) - Python client for Neovim
- **jupytext** - Required to view .ipynb files as code (not JSON)

#### Layer 2: Jupyter Support (ESSENTIAL for notebooks)
- **ipykernel** - Required to execute Python code in notebooks
- **jupyter_client** - Required for kernel communication
- **ipython** - Interactive Python shell
- **notebook** - Jupyter notebook server

#### Layer 3: Optional but Recommended
- **molten-nvim** dependencies - For cell execution UI
- **image.nvim** dependencies - For plot display

### 🎯 The RECOMMENDED Flow - Zero Configuration Required

**THE GOLDEN PATH - No :PyworksSetup Needed!**
```
1. User: Opens analysis.ipynb (NEVER ran :PyworksSetup)
2. System: Detects .ipynb extension
3. System: Checks for .venv in project → NOT FOUND
4. System: "Creating local Python environment (.venv)..."
5. System: Creates .venv in project folder
6. System: Activates .venv for all operations
7. System: Checks jupytext in .venv → NOT FOUND
8. System: "Installing jupytext in project environment..."
9. System: Installs jupytext in .venv (using .venv/bin/pip)
10. System: Reloads buffer → Now can read notebook
11. System: Reads metadata → Detects language (defaults to Python)
12. System: "Installing essential packages in .venv..."
13. System: Auto-installs in LOCAL .venv:
    - pynvim (for Neovim integration)
    - ipykernel (for execution)
    - jupyter_client (for kernel communication)
    - ipython (for interactive shell)
    - notebook (for Jupyter server)
13. System: Registers kernel with project name
14. System: Scans imports in notebook
15. System: "📦 Missing: pandas, numpy. Press <leader>pi to install"
16. User: Can now view, edit, and execute notebook
```

**When is :PyworksSetup Used? (Optional Enhancement)**
```
:PyworksSetup becomes an OPTIONAL command for:
1. Bulk package installation (web dev bundle, ML bundle, etc.)
2. Switching project templates
3. Advanced configuration
4. Troubleshooting/repair

But it's NEVER required to get started!
```

### ✅ The Zero-Config Philosophy

**Core Principle:** 
> "Users should NEVER need to run a setup command. Opening a file should be enough."

**Implementation Strategy:**
1. **Progressive Enhancement** - Install only what's needed, when it's needed
2. **Smart Defaults** - Make intelligent choices without asking
3. **Non-blocking** - Install in background while user can still read/edit
4. **Automatic Recovery** - Fix issues without user intervention

**Benefits:**
- Zero friction onboarding
- No documentation reading required
- Works like modern tools (VSCode, etc.)
- Reduces support burden

### 🏠 Local-First Package Management

**IMPORTANT: Everything installs in project-local .venv**

```lua
-- ALL packages go to .venv in project folder:
project_folder/
├── .venv/              -- Created automatically
│   ├── bin/
│   │   ├── pip         -- Local pip
│   │   ├── python      -- Local Python
│   │   └── jupyter     -- Local Jupyter
│   └── lib/
│       └── python3.x/
│           └── site-packages/  -- ALL packages here
├── analysis.ipynb
└── data.csv
```

**Why Local-Only?**
1. **Project isolation** - Each project has its own dependencies
2. **Version control** - requirements.txt tracks project needs
3. **No conflicts** - Different projects can use different versions
4. **Easy cleanup** - Delete .venv to remove everything
5. **Reproducible** - Clone project, recreate exact environment

**Package Manager Detection (respects use_uv setting):**
```lua
-- User configuration in setup:
require("pyworks").setup({
    python = {
        use_uv = true,  -- Prefer uv when available (default: true)
    }
})

function detect_package_manager()
    -- For EXISTING venv: Always respect what's already there
    if has_venv() then
        -- 1. Check if venv was created with uv
        if file_exists(".venv/bin/uv") then
            return "uv"  -- Venv uses uv, respect it
        else
            return "pip"  -- Venv uses pip, respect it
        end
    end
    
    -- For NEW venv: Check user preference
    local config = require("pyworks.config")
    
    if config.python.use_uv then
        -- User wants uv, check if available
        if command_exists("uv") then
            return "uv"  -- Use uv for new venv
        else
            -- uv not available, fallback to pip
            vim.notify("uv not found, using pip", vim.log.levels.INFO)
            return "pip"
        end
    else
        -- User prefers pip (use_uv = false)
        return "pip"
    end
end

function create_venv_with_best_tool()
    local pm = detect_package_manager()  -- Respects use_uv setting
    
    if pm == "uv" then
        -- Create venv with uv (10-100x faster!)
        run("uv venv .venv")
        vim.notify("Created venv with uv (fast!)", vim.log.levels.INFO)
    else
        -- Create standard Python venv
        run("python -m venv .venv")
        vim.notify("Created venv with pip", vim.log.levels.INFO)
    end
end

function install_package(package_name)
    local pm = detect_package_manager()
    
    if not has_venv() then
        create_venv_with_best_tool()  -- Respects use_uv setting
        pm = detect_package_manager()  -- Re-detect after creation
    end
    
    if pm == "uv" then
        -- Use uv (faster)
        run("uv pip install --python .venv/bin/python " .. package_name)
    else
        -- Use standard pip
        run(".venv/bin/pip install " .. package_name)
    end
end
```

**Detection Flow (Respects Existing Environments):**
```
Need to install packages?
    ↓
Does .venv exist?
    ├─ YES (Existing venv) → RESPECT what's there
    │   ├─ Has .venv/bin/uv → Use uv
    │   └─ No uv → Use pip (even if use_uv=true)
    │
    └─ NO (Need new venv) → Check use_uv setting
        ├─ use_uv = true (default)
        │   ├─ System has uv → Create with uv
        │   └─ No uv → Fallback to pip
        │
        └─ use_uv = false
            └─ Always create with pip

PRINCIPLE: Never change existing venv's package manager!
```

**Configuration Examples:**
```lua
-- Default: Prefer uv for speed
require("pyworks").setup({
    python = {
        use_uv = true,  -- Use uv for NEW venvs if available
    }
})

-- Conservative: Always use pip
require("pyworks").setup({
    python = {
        use_uv = false,  -- Always use pip for NEW venvs
    }
})
```

### 📋 Auto-Install vs User Confirmation

**Should Auto-Install WITHOUT Asking (in .venv):**
```lua
-- These are non-negotiable for functionality
essential_packages = {
    "jupytext",      -- Can't view .ipynb without it
    "pynvim",        -- Can't communicate with Neovim
    "ipykernel",     -- Can't execute cells
    "jupyter_client", -- Can't connect to kernels
    "ipython",       -- Core interactive shell
    "notebook"       -- Jupyter server
}
-- ALL installed in .venv/lib/python3.x/site-packages/
```

**Should Prompt User:**
```lua
-- These are project-specific choices
optional_packages = {
    "numpy",         -- Data science
    "pandas",        -- Data analysis
    "matplotlib",    -- Plotting
    "fastapi",       -- Web framework
    "django",        -- Web framework
    -- etc.
}
```

### 📊 Comparison: Manual Setup vs Zero-Config

**Old Way (Manual Setup Required):**
```
1. User installs pyworks.nvim
2. User reads documentation
3. User runs :PyworksSetup
4. User selects project type
5. User waits for installation
6. User restarts Neovim
7. User opens .ipynb file
8. Finally ready to work
Time: 5-10 minutes + reading docs
```

**New Way (Zero-Config):**
```
1. User installs pyworks.nvim
2. User opens .ipynb file
3. Everything auto-configures
4. Ready to work
Time: 30 seconds, no docs needed
```

### 🎯 The Ideal First-Time .ipynb Experience

```
User opens analysis.ipynb for the first time ever
                    ↓
        [Automatic, no prompts]
    1. Install jupytext globally
    2. Convert notebook to readable format
    3. Detect language from metadata (default Python)
    4. Create .venv if missing
    5. Install essential packages in .venv
    6. Register Jupyter kernel
                    ↓
        [Now interactive]
    7. Scan imports
    8. Show missing packages
    9. "Press <leader>pi to install pandas, numpy, matplotlib"
                    ↓
        [User ready to work]
```

**Time to Ready:**
- First time: ~30 seconds (auto-installing essentials)
- Subsequent: < 0.5 seconds (everything cached)

### 🔄 Decision Tree for Package Installation

```
Package needed?
    ↓
Is it essential for basic functionality?
    ├─ YES → Auto-install silently
    │   └─ Examples: jupytext, pynvim, ipykernel
    └─ NO → Is it imported in the file?
        ├─ YES → Notify and offer one-key install
        │   └─ Examples: pandas, requests, torch
        └─ NO → Don't mention it
```

## 🎯 Summary: The Simplified Universal Workflow

### For ANY file type (.py, .jl, .R, .ipynb):

```mermaid
graph TD
    A[Open File] --> B{Detect Type}
    B -->|.ipynb| C[Read Metadata]
    B -->|.py| D[Python Flow]
    B -->|.jl| E[Julia Flow]
    B -->|.R| F[R Flow]
    
    C -->|Has Language| G{Which Language?}
    C -->|No Language| H[Default to Python]
    
    G -->|Python| D
    G -->|Julia| E
    G -->|R| F
    H --> D
    
    D --> I[Check/Create .venv]
    E --> J[Check/Install IJulia]
    F --> K[Check/Install IRkernel]
    
    I --> L[Check/Install Packages]
    J --> L
    K --> L
    
    L --> M[Ready to Code!]
```

### The Three Golden Rules:

1. **Auto-detect everything possible** - File type, language, existing environments
2. **Default to Python when uncertain** - Most common use case
3. **One-click fixes for everything** - Missing packages, kernels, environments

### First-Time vs Subsequent Access:

**First-Time Access** (Never opened this file/project):
- Shows setup prompts and notifications
- Creates environments if needed
- Installs required packages
- Configures kernels
- May take 5-30 seconds

**Subsequent Access** (Returning to work):
- Silent initialization (cached checks)
- Instant readiness (< 0.5 seconds)
- Only notifies if new packages needed
- Background validation
- Seamless continuation

### What Makes .ipynb Special:

- **Language-agnostic**: Can be Python, Julia, R, or others
- **Metadata-driven**: Language info stored in JSON metadata
- **Requires jupytext**: To display as code instead of JSON
- **Smart defaults**: When metadata missing, default to Python

## 📦 Automatic Package Detection & Installation

### How Package Detection Works

#### For Python (.py and .ipynb):

**Step 1: Scan for imports**
```python
# The system scans for:
import numpy
import pandas as pd
from sklearn.model_selection import train_test_split
from torch import nn
import matplotlib.pyplot as plt
```

**Step 2: Extract package names**
```lua
detected_packages = {
    "numpy",           -- from: import numpy
    "pandas",          -- from: import pandas as pd
    "scikit-learn",    -- from: from sklearn... (maps sklearn → scikit-learn)
    "torch",           -- from: from torch...
    "matplotlib"       -- from: import matplotlib...
}
```

**Step 3: Check what's installed IN LOCAL VENV**
```bash
# System auto-detects and runs appropriate command:

# If uv is detected in project:
uv pip list --python .venv/bin/python --format=json

# Otherwise use standard pip:
.venv/bin/pip list --format=json

# Returns: ["numpy", "pandas"]  # Already installed in .venv
```

**Step 4: Identify missing**
```lua
installed = {"numpy", "pandas"}
missing = {"scikit-learn", "torch", "matplotlib"}
```

**Step 5: Show notification (ONLY if packages missing)**
```
📦 Missing packages: scikit-learn, torch, matplotlib
>>> Press <leader>pi to install
```

**Step 6: User presses <leader>pi**
```bash
# System runs (ALWAYS in local venv):
.venv/bin/pip install scikit-learn torch matplotlib
# or with uv:
.venv/bin/uv pip install scikit-learn torch matplotlib
```

**Step 7: No more notifications**
```
# Next time opening file:
# All packages installed → NO notification shown
# Silent success!
```

#### For Julia (.jl):

**Detection:**
```julia
using DataFrames
using Plots
import Statistics
```

**Check installed:**
```julia
# System runs:
julia -e "using Pkg; Pkg.status()"
```

**Show missing (if any):**
```
📦 Missing Julia packages: DataFrames, Plots
>>> Press <leader>pi to install
```

#### For R (.R):

**Detection:**
```r
library(ggplot2)
library(dplyr)
require(tidyr)
```

**Check installed:**
```r
# System runs:
Rscript -e "installed.packages()[,'Package']"
```

**Show missing (if any):**
```
📦 Missing R packages: ggplot2, dplyr
>>> Press <leader>pi to install
```

### 🎯 Smart Package Detection Features

#### Package Name Mapping (Python):
```lua
package_mappings = {
    ["sklearn"] = "scikit-learn",
    ["PIL"] = "Pillow",
    ["cv2"] = "opencv-python",
    ["bs4"] = "beautifulsoup4",
    -- etc.
}
```

#### Import Pattern Recognition:
```lua
-- Handles various import styles:
"import package"                    → package
"import package as alias"           → package
"from package import something"     → package
"from package.submodule import x"   → package
```

#### Intelligent Caching:
```lua
-- Cache installed packages for 5 minutes
-- Avoids repeated pip/conda checks
cache.installed_packages = {
    packages = ["numpy", "pandas", ...],
    timestamp = os.time(),
    ttl = 300  -- 5 minutes
}
```

### 📊 Complete Package Detection Flow

```mermaid
graph TD
    A[Open File] --> B[Scan Imports]
    B --> C{Cached List Fresh?}
    C -->|No| D[Get Installed Packages]
    C -->|Yes| E[Use Cached List]
    D --> F[Compare with Imports]
    E --> F
    F --> G{Any Missing?}
    G -->|No| H[Silent - Ready to Work]
    G -->|Yes| I[Show Missing Notification]
    I --> J[User Presses leader-pi]
    J --> K[Install Missing]
    K --> L[Update Cache]
    L --> H
```

### 🔄 When Package Detection Happens

**Triggers:**
1. **File Open** - Initial scan
2. **File Save** - Re-scan for new imports
3. **Manual** - `<leader>pa` to analyze imports

**Smart Behavior:**
- **First open**: Full scan and check
- **Already installed**: Silent, no notification
- **New import added**: Detect on save
- **Installation in progress**: No duplicate notifications

### 📓 Special Handling for .ipynb Files

**Notebook Package Detection:**
```python
# Scans ALL code cells in the notebook:
# Cell 1:
import numpy as np
import pandas as pd

# Cell 5:
from sklearn.ensemble import RandomForestClassifier

# Cell 10:
import seaborn as sns
```

**Result:**
```lua
-- Aggregates imports from all cells:
detected = {"numpy", "pandas", "scikit-learn", "seaborn"}
```

**Smart Notebook Behavior:**
- Scans all code cells, not just first
- Ignores markdown cells
- Handles cell execution order
- Works with jupytext conversion

### ✅ The "Only Once" Principle

**First time opening file with imports:**
```
Open file → Scan → Find missing → Show notification → Install → Done
```

**Second time (everything installed):**
```
Open file → Scan → All present → Silent (no notification) → Ready
```

**After adding new import:**
```
Edit file → Add "import requests" → Save → Detect new → Show only "requests" missing
```

### 📋 Language-Specific Package Detection

#### Python Specifics:
- Handles virtual environments correctly
- Maps import names to package names
- Checks Python version compatibility
- Supports pip, uv, conda

#### Julia Specifics:
- Detects `using` and `import` statements
- Checks Julia package registry
- Handles package versions

#### R Specifics:
- Detects `library()` and `require()` calls
- Checks R package repository
- Handles CRAN and Bioconductor

## 🚀 The Complete Zero-Config Experience

### For ALL File Types - No Setup Required!

**Python File (.py):**
```
Open file → Auto-create .venv → Install pynvim → Scan imports → Ready
```

**Jupyter Notebook (.ipynb):**
```
Open file → Install jupytext → Create .venv → Install essentials → Ready
```

**Julia File (.jl):**
```
Open file → Check Julia → Prompt for IJulia if needed → Ready
```

**R File (.R):**
```
Open file → Check R → Prompt for IRkernel if needed → Ready
```

### The Magic: Everything Just Works™

1. **No manual setup commands**
2. **No documentation required**
3. **No configuration files**
4. **No restart needed**
5. **Just open a file and start coding**

### 📦 Smart Package Manager Selection

**Core Principle: Respect Existing, Configure New**

**Scenarios:**

1. **Existing pip venv + use_uv=true**
   ```
   .venv exists (created with pip)
   User has use_uv = true
   → Still uses pip (respects existing)
   ```

2. **Existing uv venv + use_uv=false**
   ```
   .venv exists (created with uv)
   User has use_uv = false
   → Still uses uv (respects existing)
   ```

3. **No venv + use_uv=true + uv available**
   ```
   No .venv exists
   User has use_uv = true (default)
   System has uv installed
   → Creates venv with uv (fast!)
   ```

4. **No venv + use_uv=true + no uv**
   ```
   No .venv exists
   User has use_uv = true
   System doesn't have uv
   → Falls back to pip with notification
   ```

5. **No venv + use_uv=false**
   ```
   No .venv exists
   User has use_uv = false
   → Always creates with pip (user preference)
   ```

**Speed Comparison:**
- `uv`: 10-100x faster than pip
- `pip`: Standard, always works
- Existing venvs: Never modified, always respected!

### What :PyworksSetup Becomes

Instead of being required, `:PyworksSetup` becomes a power-user tool:
- **:PyworksWeb** - Quick web dev environment
- **:PyworksData** - Full data science stack
- **:PyworksML** - Machine learning packages
- **:PyworksRepair** - Fix broken environments

But none of these are needed to get started!

## 🎬 Complete Python Notebook (.ipynb) Example: First Time vs Second Time

### First Time Opening test_python_ipynb.ipynb (Nothing Set Up)

```python
# Notebook content (in cells):
# Cell 1:
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Cell 2:
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# Cell 3:
import seaborn as sns
df = pd.read_csv("data.csv")
```

**What happens (First Time - Complete Setup):**
```
1. User: Opens test_python_ipynb.ipynb for the first time
2. System: Detects .ipynb extension
3. System: Attempts to read notebook with jupytext
   → NOT FOUND
4. System: "📓 Notebook support not configured. Installing jupytext..."
5. System: Checks for .venv
   → NOT FOUND
6. System: "Creating Python environment for notebooks..."
7. System: Checks use_uv setting (default: true)
   ├─ If uv available: Creates with uv (10x faster!)
   └─ If no uv: Creates with python -m venv
8. System: Creates .venv in project folder
9. System: "Installing notebook essentials..."
10. System: Auto-installs in .venv WITHOUT prompting:
    - jupytext (to view notebook as code)
    - pynvim (Neovim integration)
    - ipykernel (execute cells)
    - jupyter_client (kernel communication)
    - ipython (interactive shell)
    - notebook (Jupyter server)
11. System: Reloads buffer → Notebook now displays as Python code with # %% cells
12. System: Reads notebook metadata:
    ```json
    "kernelspec": {
      "language": "python",
      "name": "python3"
    }
    ```
    → Confirms Python notebook (or defaults to Python if missing)
13. System: Registers Jupyter kernel for project:
    ```bash
    .venv/bin/python -m ipykernel install --user --name project_kernel
    ```
14. System: "✓ Notebook environment ready"
15. System: Scans ALL code cells for imports:
    - numpy, pandas, matplotlib
    - sklearn → scikit-learn
    - seaborn
16. System: Checks installed packages:
    ```bash
    .venv/bin/pip list --format=json
    ```
17. System: "📦 Missing packages: numpy, pandas, matplotlib, scikit-learn, seaborn"
18. System: ">>> Press <leader>pi to install"
19. User: Presses <leader>pi
20. System: Installs all missing packages in .venv
21. System: "✓ All packages installed"
22. System: Initializes Python kernel
23. User: Can now view, edit, and EXECUTE notebook cells!

Total time: ~1-2 minutes (includes all setup and package installation)
```

### Second Time Opening test_python_ipynb.ipynb (Everything Set Up)

**What happens (Second Time):**
```
1. User: Opens test_python_ipynb.ipynb
2. System: Detects .ipynb extension
3. System: Checks jupytext (CACHED) → Available
4. System: Opens notebook as Python code (instant conversion)
5. System: Reads metadata (CACHED) → Python notebook
6. System: Checks .venv (CACHED) → Valid and ready
7. System: Checks kernel (CACHED) → Registered and ready
8. System: Scans imports (all cells)
9. System: Checks packages (CACHED) → All present
10. System: [COMPLETELY SILENT - No notifications]
11. System: Kernel auto-initialized in background
12. User: Can immediately execute cells with <leader>jl or <leader>jv

Total time: < 0.5 seconds (everything cached and instant)
```

### If User Adds New Cell with Import (Second Visit)

```python
# User adds Cell 4:
import plotly.express as px
import torch
```

**What happens:**
```
1. User: Adds new cell and saves notebook
2. System: Detects save event
3. System: Re-scans ALL cells for imports
4. System: Identifies NEW packages: plotly, torch
5. System: "📦 New packages needed: plotly, torch"
6. System: ">>> Press <leader>pi to install"
7. User: Presses <leader>pi
8. System: Installs only the new packages in .venv
9. System: "✓ plotly, torch installed"
10. User: Can immediately use new packages in cells
```

### 📝 Critical .ipynb-Specific Details:

**Why .ipynb is Special:**
1. **Requires jupytext** - Without it, shows as JSON (unreadable)
2. **Language detection** - Must read metadata to know if Python/Julia/R
3. **Cell-based scanning** - Scans ALL code cells, not just top
4. **Kernel registration** - Needs kernel for execution
5. **More dependencies** - Needs jupyter packages beyond just pynvim

**The .ipynb Setup Cascade:**
```
.ipynb file
    ↓
Need jupytext to view
    ↓
Need .venv for isolation
    ↓
Need jupyter packages in .venv
    ↓
Need kernel registered
    ↓
Need project packages
    ↓
Ready to work!
```

**File Display Transformation:**
```json
// FROM (Raw .ipynb - unreadable):
{
  "cells": [
    {
      "cell_type": "code",
      "source": ["import numpy as np\n", "import pandas as pd"],
      "metadata": {}
    }
  ]
}

// TO (With jupytext - readable):
# %% [markdown]
# # My Analysis

# %%
import numpy as np
import pandas as pd
```

**First-Time Requirements:**
- Nothing! Just open the file
- Everything auto-installs progressively

**Subsequent Access:**
- Instant (< 0.5s)
- Silent
- Ready to execute cells immediately

## 🎬 Complete Julia Notebook (.ipynb) Example: First Time vs Second Time

### First Time Opening test_julia_ipynb.ipynb (Nothing Set Up)

```julia
# Notebook metadata:
{
  "kernelspec": {
    "language": "julia",
    "name": "julia-1.9",
    "display_name": "Julia 1.9.0"
  }
}

# Notebook content (in cells):
# Cell 1:
using DataFrames
using Plots
using Statistics

# Cell 2:
using CSV
data = CSV.read("data.csv", DataFrame)

# Cell 3:
using DifferentialEquations
plot(data.x, data.y)
```

**What happens (First Time - Julia Notebook):**
```
1. User: Opens test_julia_ipynb.ipynb for the first time
2. System: Detects .ipynb extension
3. System: Attempts to read notebook with jupytext
   → NOT FOUND
4. System: "📓 Notebook support not configured. Installing jupytext..."
5. System: Checks for Python environment (needed for jupytext)
   ├─ If no .venv: Creates one for jupytext installation
   └─ If .venv exists: Uses it
6. System: Installs jupytext in .venv
7. System: Reloads buffer → Notebook displays as Julia code with # %% cells
8. System: Reads notebook metadata:
   ```json
   "kernelspec": {
     "language": "julia",
     "name": "julia-1.9"
   }
   ```
   → Detects JULIA notebook (not Python!)
9. System: "Detected Julia notebook - checking for Julia support..."
10. System: Checks for Julia installation
    ├─ If Julia not installed: "Julia not found. Please install Julia first"
    └─ If Julia installed: Continue...
11. System: Checks for IJulia kernel
    → NOT FOUND
12. System: "Julia kernel not found. Install IJulia for notebook support?"
13. User: Confirms
14. System: "Installing IJulia kernel..." (shows Julia commands)
    ```julia
    using Pkg
    Pkg.add("IJulia")
    ```
15. System: Registers Julia kernel with Jupyter
16. System: "✓ Julia kernel installed and initialized"
17. System: Scans ALL code cells for Julia imports:
    - using DataFrames
    - using Plots
    - using Statistics
    - using CSV
    - using DifferentialEquations
18. System: Checks installed Julia packages:
    ```julia
    julia -e "using Pkg; Pkg.status()"
    ```
19. System: "📦 Missing Julia packages: DataFrames, Plots, CSV, DifferentialEquations"
20. System: ">>> Press <leader>pi to install"
21. User: Presses <leader>pi
22. System: Runs:
    ```julia
    using Pkg
    Pkg.add(["DataFrames", "Plots", "CSV", "DifferentialEquations"])
    ```
23. System: "✓ Julia packages installed (may need precompilation on first use)"
24. System: Initializes Julia kernel
25. User: Can now view, edit, and EXECUTE Julia notebook cells!

Total time: ~3-5 minutes (Julia packages are large and need compilation)
```

### Second Time Opening test_julia_ipynb.ipynb (Everything Set Up)

**What happens (Second Time):**
```
1. User: Opens test_julia_ipynb.ipynb
2. System: Detects .ipynb extension
3. System: Checks jupytext (CACHED) → Available
4. System: Opens notebook as Julia code (instant conversion)
5. System: Reads metadata (CACHED) → Julia notebook
6. System: Checks Julia kernel (CACHED) → IJulia ready
7. System: Scans imports in all cells
8. System: Checks Julia packages (CACHED) → All present
9. System: [COMPLETELY SILENT - No notifications]
10. System: Julia kernel auto-initialized in background
11. User: Can immediately execute cells with <leader>jl or <leader>jv

Total time: < 0.5 seconds (everything cached and instant)
```

### If User Adds New Cell with Julia Package (Second Visit)

```julia
# User adds Cell 4:
using Flux  # Machine learning
using Makie  # Advanced plotting
```

**What happens:**
```
1. User: Adds new cell and saves notebook
2. System: Detects save event
3. System: Re-scans ALL cells for "using" statements
4. System: Identifies NEW packages: Flux, Makie
5. System: "📦 New Julia packages needed: Flux, Makie"
6. System: ">>> Press <leader>pi to install"
7. User: Presses <leader>pi
8. System: Pkg.add(["Flux", "Makie"])
9. System: "✓ Flux, Makie installed (first run will precompile)"
10. User: First execution of new packages may be slow (compilation)
11. User: Subsequent runs are fast
```

### 📝 Julia Notebook Specific Details:

**Key Differences from Python Notebooks:**
1. **Language detection** - Reads "julia" from metadata
2. **No local environment needed** - Julia uses global/project packages
3. **IJulia kernel** - Different from ipykernel
4. **Package compilation** - First use after install is slow
5. **Project.toml support** - Can use project-specific dependencies

**Julia Environment Detection:**
```julia
# If Project.toml exists in folder:
1. System: "Julia project detected (Project.toml found)"
2. System: Activates project environment:
   using Pkg
   Pkg.activate(".")
   Pkg.instantiate()
3. All packages install to project, not globally
```

**Mixed Language Setup:**
```
# .venv is still created for Python tools:
project_folder/
├── .venv/              # For jupytext, pynvim (Python tools)
├── Project.toml        # Julia project (optional)
├── Manifest.toml       # Julia lock file (optional)
└── test_julia_ipynb.ipynb
```

**First-Time Requirements:**
- Julia must be installed
- Everything else auto-installs

**Subsequent Access:**
- Instant (< 0.5s)
- Silent
- Ready to execute Julia cells

## 🎬 Complete R Notebook (.ipynb) Example: First Time vs Second Time

### First Time Opening test_r_ipynb.ipynb (Nothing Set Up)

```r
# Notebook metadata:
{
  "kernelspec": {
    "language": "R",
    "name": "ir",
    "display_name": "R"
  }
}

# Notebook content (in cells):
# Cell 1:
library(ggplot2)
library(dplyr)
library(tidyverse)

# Cell 2:
library(readr)
data <- read_csv("data.csv")

# Cell 3:
library(plotly)
ggplot(data, aes(x = x, y = y)) + geom_point()
```

**What happens (First Time - R Notebook):**
```
1. User: Opens test_r_ipynb.ipynb for the first time
2. System: Detects .ipynb extension
3. System: Attempts to read notebook with jupytext
   → NOT FOUND
4. System: "📓 Notebook support not configured. Installing jupytext..."
5. System: Checks for Python environment (needed for jupytext)
   ├─ If no .venv: Creates one for jupytext installation
   └─ If .venv exists: Uses it
6. System: Installs jupytext in .venv
7. System: Reloads buffer → Notebook displays as R code with # %% cells
8. System: Reads notebook metadata:
   ```json
   "kernelspec": {
     "language": "R",
     "name": "ir"
   }
   ```
   → Detects R notebook (not Python or Julia!)
9. System: "Detected R notebook - checking for R support..."
10. System: Checks for R installation
    ├─ If R not installed: "R not found. Please install R first"
    └─ If R installed: Continue...
11. System: Checks for IRkernel (R Jupyter kernel)
    → NOT FOUND
12. System: "R kernel not found. Install IRkernel for notebook support?"
13. User: Confirms
14. System: "Installing IRkernel..." (shows R commands)
    ```r
    install.packages('IRkernel')
    IRkernel::installspec(user = FALSE, name = 'ir', displayname = 'R')
    ```
15. System: Registers R kernel with Jupyter
16. System: "✓ R kernel installed and initialized"
17. System: Scans ALL code cells for R packages:
    - library(ggplot2)
    - library(dplyr)
    - library(tidyverse)
    - library(readr)
    - library(plotly)
18. System: Checks installed R packages:
    ```r
    Rscript -e "installed.packages()[,'Package']"
    ```
19. System: "📦 Missing R packages: ggplot2, dplyr, tidyverse, readr, plotly"
20. System: ">>> Press <leader>pi to install"
21. User: Presses <leader>pi
22. System: Runs:
    ```r
    install.packages(c('ggplot2', 'dplyr', 'tidyverse', 'readr', 'plotly'))
    ```
23. System: "✓ R packages installed"
24. System: Initializes R kernel
25. User: Can now view, edit, and EXECUTE R notebook cells!

Total time: ~2-3 minutes (R packages installation from CRAN)
```

### Second Time Opening test_r_ipynb.ipynb (Everything Set Up)

**What happens (Second Time):**
```
1. User: Opens test_r_ipynb.ipynb
2. System: Detects .ipynb extension
3. System: Checks jupytext (CACHED) → Available
4. System: Opens notebook as R code (instant conversion)
5. System: Reads metadata (CACHED) → R notebook
6. System: Checks R kernel (CACHED) → IRkernel ready
7. System: Scans imports in all cells
8. System: Checks R packages (CACHED) → All present
9. System: [COMPLETELY SILENT - No notifications]
10. System: R kernel auto-initialized in background
11. User: Can immediately execute cells with <leader>jl or <leader>jv

Total time: < 0.5 seconds (everything cached and instant)
```

### If User Adds New Cell with R Package (Second Visit)

```r
# User adds Cell 4:
library(shiny)  # Web apps
library(caret)  # Machine learning
```

**What happens:**
```
1. User: Adds new cell and saves notebook
2. System: Detects save event
3. System: Re-scans ALL cells for library() and require() calls
4. System: Identifies NEW packages: shiny, caret
5. System: "📦 New R packages needed: shiny, caret"
6. System: ">>> Press <leader>pi to install"
7. User: Presses <leader>pi
8. System: install.packages(c('shiny', 'caret'))
9. System: "✓ shiny, caret installed"
10. User: Can immediately use new packages
```

### 📝 R Notebook Specific Details:

**Key Differences from Python/Julia Notebooks:**
1. **Language detection** - Reads "R" from metadata
2. **Global package installation** - R packages install to user/system library
3. **IRkernel** - Different from ipykernel and IJulia
4. **CRAN repository** - Packages come from CRAN (or Bioconductor)
5. **No environment isolation** - R doesn't use virtual environments

**R Package Locations:**
```r
# R packages install to:
# User library: ~/R/x86_64-pc-linux-gnu-library/4.3/
# or System: /usr/local/lib/R/site-library/
# NOT in project folder (unlike Python .venv)
```

**Mixed Language Setup:**
```
# .venv is created for Python tools only:
project_folder/
├── .venv/              # For jupytext, pynvim (Python tools)
├── test_r_ipynb.ipynb  # R notebook
└── data.csv           # Data file
```

**R-Specific Package Detection:**
```lua
-- Scans for R package patterns:
"library(package)"    → package
"require(package)"    → package
"library('package')"  → package
"library("package")"  → package
```

**First-Time Requirements:**
- R must be installed
- Everything else auto-installs

**Subsequent Access:**
- Instant (< 0.5s)
- Silent
- Ready to execute R cells

## 📊 Complete Notebook Comparison Table

| Aspect | Python .ipynb | Julia .ipynb | R .ipynb |
|--------|---------------|--------------|----------|
| **Metadata Language** | "python" | "julia" | "R" |
| **Kernel Name** | python3 | julia-1.9 | ir |
| **Kernel Package** | ipykernel | IJulia | IRkernel |
| **Environment** | .venv (local) | Project.toml or global | Global library |
| **Package Install** | pip/uv in .venv | Pkg.add() | install.packages() |
| **Import Detection** | import/from | using/import | library()/require() |
| **First Setup Time** | ~1-2 min | ~3-5 min | ~2-3 min |
| **Second Access** | < 0.5s | < 0.5s | < 0.5s |
| **Silent When Ready** | ✅ Yes | ✅ Yes | ✅ Yes |

### The Universal Notebook Experience:

**No matter the language (Python/Julia/R):**
1. **First time**: Auto-detects language, installs everything needed
2. **Second time**: Silent, instant, ready to execute
3. **New packages**: Only prompts for what's new
4. **Zero manual setup**: Just open the file!

**The only difference is WHERE packages install:**
- Python: Local .venv in project
- Julia: Global or Project.toml
- R: Global R library

**Unknown/Missing Language Metadata:**
```
1. Detects .ipynb
2. Can't determine language from metadata
3. Defaults to Python (most common)
4. Shows: "No language detected, defaulting to Python"
5. Continues with Python setup flow
```

## 🎬 Complete Python File Example: First Time vs Second Time

### First Time Opening test_python.py (No venv exists)

```python
# File content:
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import requests

data = pd.read_csv("data.csv")
```

**What happens (First Time):**
```
1. User: Opens test_python.py for the first time
2. System: Detects .py extension
3. System: "Detected Python file - checking for environment..."
4. System: Checks for .venv in project folder
   → NOT FOUND
5. System: "No virtual environment found. Creating .venv..."
6. System: Checks use_uv setting (default: true)
   ├─ If uv available: Creates venv with uv (fast!)
   └─ If no uv: Creates with python -m venv
7. System: "Creating virtual environment..." (with progress)
8. System: Activates .venv for all operations
9. System: "Installing essential packages..."
10. System: Auto-installs in .venv WITHOUT prompting:
    - pynvim (Neovim integration)
    - ipykernel (Jupyter support)
    - jupyter_client (kernel communication)
11. System: "✓ Python environment ready"
12. System: Scans imports in file:
    - numpy → maps to numpy
    - pandas → maps to pandas
    - sklearn → maps to scikit-learn
    - matplotlib → maps to matplotlib
    - requests → maps to requests
13. System: Checks installed packages in .venv:
    ```bash
    .venv/bin/pip list --format=json
    ```
14. System: "📦 Missing packages: numpy, pandas, matplotlib, scikit-learn, requests"
15. System: ">>> Press <leader>pi to install"
16. User: Presses <leader>pi
17. System: Runs (if uv detected):
    ```bash
    uv pip install --python .venv/bin/python numpy pandas matplotlib scikit-learn requests
    ```
    Or with pip:
    ```bash
    .venv/bin/pip install numpy pandas matplotlib scikit-learn requests
    ```
18. System: "✓ Packages installed successfully"
19. System: Registers Jupyter kernel for project
20. User: Ready to execute Python code!

Total time: ~30s-1min (faster with uv, slower with pip)
```

### Second Time Opening test_python.py (Everything Already Set Up)

**What happens (Second Time):**
```
1. User: Opens test_python.py
2. System: Detects .py extension
3. System: Checks for .venv (CACHED - instant)
   → FOUND: .venv exists and valid
4. System: Silently activates venv
5. System: Checks Python kernel (CACHED)
   → FOUND and initialized
6. System: Scans imports
7. System: Checks installed packages (CACHED for 5 min)
   → All packages present
8. System: [COMPLETELY SILENT - No notifications]
9. User: Can immediately start coding

Total time: < 0.5 seconds
```

### Special Case: First Time with EXISTING .venv

```python
# User cloned a project that already has .venv
```

**What happens:**
```
1. User: Opens test_python.py (project has .venv)
2. System: Detects .py extension
3. System: Checks for .venv
   → FOUND: Existing .venv
4. System: "Using existing virtual environment: .venv"
5. System: Validates Python version in venv
6. System: Checks for essential packages:
   ├─ pynvim missing? → Auto-installs
   ├─ ipykernel missing? → Auto-installs
   └─ All present? → Continue silently
7. System: Respects existing package manager:
   ├─ Has .venv/bin/uv → Uses uv
   └─ No uv → Uses pip
8. System: Scans imports
9. System: "📦 Missing packages: pandas, numpy"
10. System: ">>> Press <leader>pi to install"
11. User: Installs missing packages
12. Ready to work!

Key: RESPECTS and USES existing venv, never recreates
```

### If User Adds New Import (Second Visit)

```python
# User adds:
import tensorflow as tf  # New addition
```

**What happens:**
```
1. User: Saves file with new import
2. System: Detects file save
3. System: Re-scans imports
4. System: Identifies new package: tensorflow
5. System: Checks Python version compatibility
   ├─ If Python 3.12+: "⚠️ TensorFlow has limited support for Python 3.12+"
   │                    "Consider alternatives: torch, jax"
   └─ If compatible: Continue
6. System: "📦 New package needed: tensorflow"
7. System: ">>> Press <leader>pi to install"
8. User: Presses <leader>pi
9. System: Installs in .venv (respects pip/uv from venv creation)
10. System: "✓ tensorflow installed"
```

### 📝 Important Python-Specific Notes:

**Key Python Features:**
1. **Always uses .venv** - Local project isolation
2. **Smart package mapping** - sklearn → scikit-learn, PIL → Pillow
3. **Compatibility checking** - Warns about version conflicts
4. **Respects package manager** - Uses same tool (pip/uv) that created venv
5. **Auto-essentials** - pynvim, ipykernel install without asking

**Virtual Environment Behavior:**
```bash
project_folder/
├── .venv/                  # Created automatically
│   ├── bin/
│   │   ├── python         # Project Python
│   │   ├── pip            # Project pip
│   │   └── jupyter        # Project Jupyter
│   └── lib/python3.x/
│       └── site-packages/ # ALL packages here
├── test_python.py
└── requirements.txt       # Can generate with pip freeze
```

**Package Manager Detection (Existing venv):**
```lua
-- Check what created the venv:
if file_exists(".venv/bin/uv") then
    -- Use uv (faster)
    use_uv_for_installs()
else
    -- Use pip (standard)
    use_pip_for_installs()
end
-- NEVER changes existing venv's package manager
```

**First-Time Requirements:**
- Python installed on system
- That's it! Everything else auto-installs

**Subsequent Access is Lightning Fast:**
- Everything cached
- Silent activation
- Only notifies for new imports
- Instant readiness

## 🎬 Complete Julia File Example: First Time vs Second Time

### First Time Opening test_julia.jl (No Julia Kernel Installed)

```julia
# File content:
using DataFrames
using Plots
using Statistics
import CSV

data = CSV.read("data.csv", DataFrame)
```

**What happens (First Time):**
```
1. User: Opens test_julia.jl for the first time
2. System: Detects .jl extension
3. System: "Detected Julia file - checking for Jupyter support..."
4. System: Checks for Julia installation
   ├─ If Julia not installed: "Julia not found. Please install Julia first"
   └─ If Julia installed: Continue...
5. System: Checks for IJulia kernel
   → NOT FOUND
6. System: "Julia kernel not found. Install IJulia for notebook support?"
7. User: Confirms
8. System: Shows command or auto-runs:
   ```julia
   using Pkg
   Pkg.add("IJulia")
   ```
9. System: "Installing IJulia..." (with progress)
10. System: Registers Julia kernel with Jupyter
11. System: "✓ Julia kernel installed and initialized"
12. System: Scans for 'using' and 'import' statements
13. System: Checks installed Julia packages:
    ```julia
    julia -e "using Pkg; Pkg.status()"
    ```
14. System: "📦 Missing Julia packages: DataFrames, Plots, CSV"
15. System: ">>> Press <leader>pi to install"
16. User: Presses <leader>pi
17. System: Runs:
    ```julia
    using Pkg
    Pkg.add(["DataFrames", "Plots", "CSV"])
    ```
18. System: "✓ Julia packages installed"
19. User: Ready to execute Julia code with Jupyter integration!

Total time: ~2-3 minutes (Julia packages can be large)
```

### Second Time Opening test_julia.jl (Everything Already Set Up)

**What happens (Second Time):**
```
1. User: Opens test_julia.jl
2. System: Detects .jl extension
3. System: Checks for Julia kernel (CACHED - instant)
   → FOUND: julia-1.9 kernel (or similar)
4. System: Silently initializes Julia kernel
5. System: Scans for using/import statements
6. System: Checks installed packages (CACHED for 5 min)
   → All packages present (DataFrames, Plots, CSV)
7. System: [SILENT - No notifications]
8. User: Can immediately execute code

Total time: < 0.5 seconds
```

### If User Adds New Package (Second Visit)

```julia
# User adds:
using DifferentialEquations  # New addition
```

**What happens:**
```
1. User: Saves file with new using statement
2. System: Detects file save
3. System: Re-scans using/import statements
4. System: Compares with installed packages
5. System: "📦 New Julia package needed: DifferentialEquations"
6. System: ">>> Press <leader>pi to install"
7. User: Presses <leader>pi
8. System: Pkg.add("DifferentialEquations")
9. System: "✓ DifferentialEquations installed"
   (Note: This might take longer as it's a large package)
```

### 📝 Important Julia-Specific Notes:

**Key Differences from Python/R:**
1. **Project environments** - Julia can use project-specific or global environments
2. **IJulia is the Jupyter kernel** - Enables notebook execution
3. **Package detection** - Scans for `using` and `import` statements
4. **Compiled packages** - First use of packages can be slow (precompilation)

**Julia Package Management:**
```julia
# Julia has sophisticated package management:
# - Global environment: ~/.julia/environments/v1.9/
# - Project environment: ./Project.toml & ./Manifest.toml
# - Can activate project-specific environments
```

**Project-Specific Environment (if Project.toml exists):**
```
1. System detects Project.toml in folder
2. System: "Julia project detected. Activating project environment..."
3. System: Runs with project environment:
   ```julia
   using Pkg
   Pkg.activate(".")
   Pkg.instantiate()  # Install all project dependencies
   ```
4. All packages install to project, not globally
```

**First-Time Setup Requirements:**
- Julia must be installed on system
- IJulia for Jupyter integration
- Individual Julia packages as needed

**Subsequent Access is Fast:**
- Everything cached
- Silent initialization
- Only notifies for new packages
- Note: First run after package install may be slower (precompilation)

## 🎬 Complete R File Example: First Time vs Second Time

### First Time Opening test_r.R (No R Kernel Installed)

```r
# File content:
library(ggplot2)
library(dplyr)
library(tidyr)

data <- read.csv("data.csv")
```

**What happens (First Time):**
```
1. User: Opens test_r.R for the first time
2. System: Detects .R extension
3. System: "Detected R file - checking for Jupyter support..."
4. System: Checks for R installation
   ├─ If R not installed: "R not found. Please install R first"
   └─ If R installed: Continue...
5. System: Checks for IRkernel (R Jupyter kernel)
   → NOT FOUND
6. System: "R kernel not found. Install IRkernel to execute cells?"
7. User: Confirms
8. System: Shows command or auto-runs:
   ```r
   install.packages('IRkernel')
   IRkernel::installspec(user = FALSE, name = 'ir', displayname = 'R')
   ```
9. System: "Installing IRkernel..." (with progress)
10. System: "✓ R kernel installed and initialized"
11. System: Scans for library() and require() calls
12. System: Checks installed R packages:
    ```r
    Rscript -e "installed.packages()[,'Package']"
    ```
13. System: "📦 Missing R packages: ggplot2, dplyr, tidyr"
14. System: ">>> Press <leader>pi to install"
15. User: Presses <leader>pi
16. System: Runs:
    ```r
    install.packages(c('ggplot2', 'dplyr', 'tidyr'))
    ```
17. System: "✓ R packages installed"
18. User: Ready to execute R code with Jupyter integration!

Total time: ~1-2 minutes (mostly package installation)
```

### Second Time Opening test_r.R (Everything Already Set Up)

**What happens (Second Time):**
```
1. User: Opens test_r.R
2. System: Detects .R extension
3. System: Checks for R kernel (CACHED - instant)
   → FOUND: ir kernel
4. System: Silently initializes R kernel
5. System: Scans for library() calls
6. System: Checks installed packages (CACHED for 5 min)
   → All packages present (ggplot2, dplyr, tidyr)
7. System: [SILENT - No notifications]
8. User: Can immediately execute code

Total time: < 0.5 seconds
```

### If User Adds New Library (Second Visit)

```r
# User adds:
library(plotly)  # New addition
```

**What happens:**
```
1. User: Saves file with new library(plotly)
2. System: Detects file save
3. System: Re-scans library() calls
4. System: Compares with installed packages
5. System: "📦 New R package needed: plotly"
6. System: ">>> Press <leader>pi to install"
7. User: Presses <leader>pi
8. System: install.packages('plotly')
9. System: "✓ plotly installed"
```

### 📝 Important R-Specific Notes:

**Key Differences from Python:**
1. **No virtual environments** - R packages install globally or per-user
2. **IRkernel is the Jupyter kernel** - Enables notebook execution
3. **Package detection** - Scans for `library()` and `require()` calls
4. **Installation location** - R packages go to R library, not project folder

**R Package Installation Behavior:**
```r
# Packages install to R's library path:
# ~/.R/library/ (user)
# or /usr/local/lib/R/site-library (system)
# NOT in project folder like Python's .venv
```

**First-Time Setup Requirements:**
- R must be installed on system
- IRkernel for Jupyter integration
- Individual R packages as needed

**Subsequent Access is Fast:**
- Everything cached
- Silent initialization
- Only notifies for new packages

## 📊 Language Comparison: First-Time Setup

| Aspect | Python | Julia | R |
|--------|--------|-------|---|
| **File Extension** | .py, .ipynb | .jl | .R |
| **Environment** | .venv (local) | Project.toml or global | Global/user library |
| **Kernel** | ipykernel | IJulia | IRkernel |
| **Package Manager** | pip/uv | Pkg | install.packages() |
| **Import Syntax** | `import`, `from...import` | `using`, `import` | `library()`, `require()` |
| **Package Location** | .venv/lib/python3.x/ | ~/.julia or project | ~/.R/library |
| **First-Time Setup** | ~30s-1min | ~2-3min | ~1-2min |
| **Second Access** | <0.5s | <0.5s | <0.5s |
| **Package Detection** | ✅ Automatic | ✅ Automatic | ✅ Automatic |
| **Auto-install Essential** | ✅ Yes | ✅ IJulia only | ✅ IRkernel only |
| **Project Isolation** | ✅ Always (.venv) | ✅ Optional | ❌ Global |

### 🎯 The Consistent Experience Across All Languages:

**First Time Opening ANY File:**
- **Python (.py)**: Creates .venv → Installs essentials → Detects missing → Install with `<leader>pi`
- **Julia (.jl)**: Checks IJulia → Installs if needed → Detects missing → Install with `<leader>pi`
- **R (.R)**: Checks IRkernel → Installs if needed → Detects missing → Install with `<leader>pi`
- **Notebook (.ipynb)**: Detects language → Follows appropriate flow above

**Second Time Opening (Everything Installed):**
- **ALL LANGUAGES**: < 0.5 seconds, COMPLETELY SILENT, ready to work

**The Magic Formula:**
```
First time = Helpful setup wizard
Second time = Invisible and instant
New packages = Minimal interruption
```

### Universal Behavior Pattern:

**First Time (Any Language):**
1. Detect file type
2. Check for language runtime
3. Check/install Jupyter kernel
4. Scan for packages/libraries
5. Detect missing ones
6. Prompt to install with `<leader>pi`
7. Ready to work

**Second Time (Any Language):**
1. Detect file type (cached)
2. Initialize kernel silently (cached)
3. Check packages (cached)
4. **COMPLETELY SILENT if all present**
5. Ready in <0.5 seconds

**Adding New Dependencies (Any Language):**
1. Save file with new import/using/library
2. Detect only the NEW missing package
3. Prompt to install just that package
4. Continue working

## 🎬 Complete Example: Real-World Workflow

### Day 1: New Project with Notebook

```python
# User creates analysis.ipynb with this content:
# Cell 1:
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Cell 2:
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
```

**What happens:**
```
1. Open analysis.ipynb
2. System: Installing jupytext... ✓
3. System: Creating .venv... ✓
4. System: Installing notebook essentials... ✓
5. System: Scanning imports...
6. System: "📦 Missing: numpy, pandas, matplotlib, scikit-learn"
7. System: ">>> Press <leader>pi to install"
8. User: Presses <leader>pi
9. System: Installing packages... ✓
10. User: Ready to execute cells!
```

### Day 2: Return to Same Notebook

```
1. Open analysis.ipynb
2. System: [Silent - everything cached and ready]
3. User: Immediately executes cells
```

### Day 2 (Later): Add New Import

```python
# User adds to Cell 3:
import seaborn as sns
import plotly.express as px
```

**What happens:**
```
1. User saves file
2. System: Detects new imports
3. System: "📦 New packages needed: seaborn, plotly"
4. System: ">>> Press <leader>pi to install"
5. User: Presses <leader>pi
6. System: Installing only new packages... ✓
```

### Day 3: Everything Already Installed

```
1. Open analysis.ipynb
2. System: [Silent - all packages present]
3. User: Works without any interruptions
```

## 🎯 Core Vision
Pyworks.nvim should provide a seamless, zero-friction experience for working with Python, Julia, and R projects in Neovim. Users should be able to open any supported file and immediately start coding with proper environment setup, package management, and notebook support.

## 📚 User Personas

### 1. Data Scientist (Sarah)
- Uses Python, Julia, and R for analysis
- Works with Jupyter notebooks daily
- Needs quick environment switching between projects
- Values visualization and output display

### 2. Python Developer (Alex)
- Primarily uses Python for web/API development
- Occasionally uses notebooks for exploration
- Needs reliable virtual environment management
- Values fast package installation

### 3. Academic Researcher (Dr. Chen)
- Uses multiple languages for different research projects
- Needs reproducible environments
- Works with existing notebooks from colleagues
- Values compatibility and stability

### 4. ML Engineer (Jordan)
- Heavy notebook user for experimentation
- Needs GPU-aware environments
- Works with large datasets and models
- Values performance and resource management

## 🚀 Primary User Stories

### Story 1: First-Time Notebook Access
**As a** new user opening a `.ipynb` file for the first time  
**I want** to see the notebook content in readable format (not JSON)  
**So that** I can immediately start working without manual setup

#### Acceptance Criteria:
1. When opening `.ipynb`, it displays as Python/Julia/R code with cell markers
2. Automatic detection of notebook language from metadata
3. If jupytext is missing, prompt to install with one-click action
4. After jupytext installation, auto-reload the file in correct format
5. Show clear progress indicators during setup

#### Technical Flow:
```
Open .ipynb → Check jupytext → If missing: prompt install → 
Install jupytext → Reload buffer → Display as code
```

### Story 2: Automatic Environment Detection & Setup
**As a** user opening any Python/Julia/R file  
**I want** the environment to be automatically configured  
**So that** I can run code immediately without manual setup

#### Acceptance Criteria:
1. Detect file extension (.py, .jl, .R, .ipynb)
2. Check for existing virtual environment in project
3. If no venv exists, prompt to create one
4. Auto-detect package manager preference (uv > pip)
5. For notebooks, ensure kernel is properly configured
6. Show environment status in statusline/notification

#### Technical Flow:
```
File open → Detect language → Check for venv/kernel → 
If missing: prompt creation → Setup environment → 
Configure kernel → Ready notification
```

### Story 3: Smart Package Installation
**As a** user with missing packages  
**I want** to be notified and install them with one action  
**So that** I don't waste time debugging import errors

#### Acceptance Criteria:
1. Scan file for import statements on open
2. Detect missing packages accurately
3. Handle package name mappings (PIL → Pillow)
4. Check Python version compatibility
5. Show "Press <leader>pi to install" notification
6. Install all compatible packages in one go
7. Skip incompatible packages with explanation
8. Show installation progress and results

#### Technical Flow:
```
Scan imports → Check installed packages → Identify missing → 
Check compatibility → Show notification → User presses <leader>pi → 
Install packages → Show results
```

### Story 4: Project Template Selection
**As a** user running :PyworksSetup  
**I want** to choose from relevant project templates  
**So that** I get the right packages for my use case

#### Acceptance Criteria:
1. Show interactive menu with project types
2. Categories: Data Science, Web Dev, General, Automation, Custom
3. Each template shows package list preview
4. Option to modify package list before installation
5. Remember last selection for similar projects
6. Support for .pyworks.yaml project config

#### Example Templates:
- **Data Science**: numpy, pandas, matplotlib, scikit-learn, jupyter, ipykernel
- **Web Development**: fastapi/flask/django, sqlalchemy, pytest, black
- **Machine Learning**: torch/tensorflow, transformers, datasets, wandb
- **Custom**: User selects packages manually

### Story 5: Multi-Language Kernel Management
**As a** polyglot data scientist  
**I want** to work with Python, Julia, and R seamlessly  
**So that** I can use the best tool for each task

#### Acceptance Criteria:
1. Auto-detect language from file extension
2. Check for appropriate kernel installation
3. Prompt to install kernel if missing
4. Use project-specific kernels when available
5. Switch kernels without restarting Neovim
6. Share data between languages (future feature)

#### Language-Specific Flows:

**Python:**
```
.py/.ipynb → Check for ipykernel → Check venv → 
Create/activate venv → Install ipykernel → Register kernel
```

**Julia:**
```
.jl → Check for IJulia → Prompt to install if missing → 
using Pkg; Pkg.add("IJulia") → Initialize kernel
```

**R:**
```
.R → Check for IRkernel → Prompt to install if missing → 
install.packages("IRkernel") → IRkernel::installspec()
```

### Story 6: Existing Project Onboarding
**As a** developer cloning an existing project  
**I want** the environment to be automatically configured  
**So that** I can start contributing immediately

#### Acceptance Criteria:
1. Detect requirements.txt/pyproject.toml/environment.yml
2. Prompt to create venv from requirements
3. Install all dependencies with progress indicator
4. Handle version conflicts gracefully
5. Set up pre-commit hooks if configured
6. Configure notebooks if present

#### Technical Flow:
```
Open project → Detect dependency files → Prompt setup → 
Create venv → Install dependencies → Configure kernel → 
Run health check → Ready notification
```

### Story 7: Notebook Cell Execution
**As a** notebook user  
**I want** to execute cells with visual feedback  
**So that** I can see results immediately

#### Acceptance Criteria:
1. Execute current cell with <leader>jl
2. Execute visual selection with <leader>jv
3. Show execution indicator while running
4. Display output in floating window
5. Render plots/images (if terminal supports)
6. Show errors clearly with traceback
7. Maintain execution order/state

### Story 8: Environment Health Monitoring
**As a** user working on a project  
**I want** to know if my environment is healthy  
**So that** I can fix issues before they cause problems

#### Acceptance Criteria:
1. Periodic health checks (configurable interval)
2. Check: venv active, packages installed, kernel registered
3. Auto-fix common issues (missing pynvim, broken kernel)
4. Show status in statusline
5. Detailed diagnostics with :PyworksCheckEnvironment
6. Suggest fixes for detected issues

## 🔄 Workflow Scenarios

### 🎬 First-Time User Scenarios

#### 📓 Special Case: .ipynb Files (Jupyter Notebooks)

**Important:** .ipynb files are language-agnostic! They can contain:
- Python code (most common)
- Julia code
- R code  
- Any other Jupyter-supported language

The language is determined by the notebook's metadata, specifically:
```json
{
  "metadata": {
    "kernelspec": {
      "language": "python",  // or "julia", "R", etc.
      "name": "python3"
    }
  }
}
```

Notebooks require special handling because:
1. They need jupytext to display properly (not as JSON)
2. They contain metadata about the kernel/language
3. They need both viewing AND execution support
4. The file extension (.ipynb) doesn't tell us the language - we must read the metadata

##### First-Time .ipynb WITH Environment:

**Python Notebook with existing .venv:**
```
1. User: Opens analysis.ipynb
2. System: Detects .ipynb extension
3. System: Checks for jupytext → If missing:
   - "Notebook support not configured. Install jupytext?"
   - User confirms → Installs jupytext globally
4. System: Converts notebook from JSON to Python percent format
5. System: Reads notebook metadata → language: python
6. System: Checks for .venv → FOUND
7. System: Validates ipykernel in .venv → If missing, auto-installs
8. System: "✓ Opening notebook with Python (.venv)"
9. System: Displays notebook as readable Python code with # %% cells
10. System: Scans imports → Shows missing packages
11. User: Can read, edit, and execute cells immediately
```

**Julia Notebook with existing kernel:**
```
1. User: Opens experiments.ipynb
2. System: Checks jupytext → Ensures installed
3. System: Converts and reads metadata → language: julia
4. System: Checks for Julia kernel → FOUND julia-1.9
5. System: "✓ Opening Julia notebook"
6. System: Displays as Julia code with # %% markers
7. System: Initializes Julia kernel automatically
8. User: Ready to execute Julia cells
```

**R Notebook with existing kernel:**
```
1. User: Opens statistics.ipynb
2. System: Checks jupytext → Ensures installed
3. System: Converts and reads metadata → language: R
4. System: Checks for R kernel → FOUND ir
5. System: "✓ Opening R notebook"
6. System: Displays as R code with # %% markers
7. System: Initializes R kernel automatically
8. User: Ready to execute R cells
```

##### Universal .ipynb Workflow (Any Language):

**The Golden Path - What happens when opening ANY .ipynb:**
```
1. User: Opens any_notebook.ipynb
2. System: Detects .ipynb extension
3. System: Checks jupytext availability
   └─ If missing → Prompt to install (required for ALL notebooks)
4. System: Reads notebook metadata to detect language
   ├─ Python detected → Go to Python workflow
   ├─ Julia detected → Go to Julia workflow
   ├─ R detected → Go to R workflow
   └─ Unknown/Missing → DEFAULT TO PYTHON (most common)
      └─ Show notification: "No language detected, defaulting to Python"
5. System: Based on detected language, checks for environment:
   ├─ Python → Check for .venv and ipykernel
   ├─ Julia → Check for Julia and IJulia kernel
   └─ R → Check for R and IRkernel
6. System: If environment missing → Guided setup for that language
7. System: Initializes appropriate kernel
8. System: Displays notebook in readable format (not JSON)
9. System: Scans for missing packages (if supported)
10. User: Ready to work with notebook in their language
```

##### First-Time .ipynb WITHOUT Environment:

**Python Notebook without any setup:**
```
1. User: Opens new_analysis.ipynb (first time ever)
2. System: Detects .ipynb → Checks jupytext → NOT FOUND
3. System: "📓 Notebook files require jupytext. Install now?"
4. User: Confirms
5. System: Installs jupytext with progress indicator
6. System: Reloads buffer → Converts JSON to readable format
7. System: Reads metadata → language: python (or prompts if missing)
8. System: Checks for .venv → NOT FOUND
9. System: "No Python environment found. Create .venv?"
10. User: Confirms
11. System: Creates .venv (using uv if available)
12. System: Auto-installs essentials: pynvim, ipykernel, jupyter_client
13. System: "Select packages for your notebook:"
    - [Data Science Bundle] - numpy, pandas, matplotlib, etc.
    - [Minimal] - Just jupyter essentials
    - [Custom] - Choose your own
14. User: Selects Data Science
15. System: Installs packages with progress
16. System: Registers kernel as "project_name (Python 3.x)"
17. System: "✓ Notebook environment ready!"
18. User: Sees notebook as Python code, can execute cells
```

**Notebook with missing/corrupted metadata:**
```
1. User: Opens broken.ipynb
2. System: Attempts to read metadata → FAILED/MISSING
3. System: "Notebook metadata is missing. Select language:"
    [1] Python (default)
    [2] Julia
    [3] R
4. User: Selects Python
5. System: Fixes notebook metadata
6. System: Continues with normal Python notebook flow
7. System: "✓ Fixed notebook metadata and initialized Python kernel"
```

**Multi-language notebook (future feature):**
```
1. User: Opens polyglot.ipynb
2. System: Detects mixed cell languages in metadata
3. System: "Multi-language notebook detected. Initialize all kernels?"
4. System: Lists required: Python, Julia, R
5. User: Confirms
6. System: Initializes all three kernels
7. System: Shows kernel selector in statusline
8. User: Can switch kernels per cell
```

#### Scenario A: First Time WITH Existing Environment
**Context:** User has existing .venv, Julia kernel, or R kernel already set up in their project folder

**Python with existing .venv:**
```
1. User: Opens project/analysis.py (or .ipynb)
2. System: Detects Python file
3. System: Checks for venv → FOUND .venv/
4. System: Validates venv has Python with required version
5. System: Checks for ipykernel → If missing, auto-installs
6. System: "✓ Using existing environment: .venv"
7. System: Scans imports, detects missing packages
8. System: "📦 Missing: pandas, numpy. Press <leader>pi to install"
9. User: Can immediately start coding or install missing packages
```

**Julia with existing kernel:**
```
1. User: Opens experiment.jl
2. System: Detects Julia file
3. System: Checks for Julia kernel → FOUND julia-1.9
4. System: "✓ Julia kernel detected and initialized"
5. System: Scans for 'using' statements
6. System: "📦 Missing: DataFrames, Plots. Press <leader>pi to install"
7. User: Ready to execute Julia code
```

**R with existing kernel:**
```
1. User: Opens analysis.R
2. System: Detects R file
3. System: Checks for R kernel → FOUND ir
4. System: "✓ R kernel detected and initialized"
5. System: Scans for library() calls
6. System: "📦 Missing: ggplot2, dplyr. Press <leader>pi to install"
7. User: Ready to execute R code
```

#### Scenario B: First Time WITHOUT Environment
**Context:** Fresh project, no venv, no kernels installed

**Python without venv:**
```
1. User: Opens new_project.py (or .ipynb)
2. System: Detects Python file
3. System: Checks for venv → NOT FOUND
4. System: "No virtual environment detected. Create one?"
5. System: Shows options: [1] .venv (recommended) [2] Custom name [3] Skip
6. User: Selects option 1
7. System: Checks for uv → If available, uses it (10x faster)
8. System: Creates .venv with progress indicator
9. System: Auto-installs: pynvim, ipykernel, jupyter_client
10. System: "Would you like to select a project template?"
11. System: [Data Science] [Web] [General] [Skip]
12. User: Selects Data Science
13. System: Installs: numpy, pandas, matplotlib, scikit-learn, etc.
14. System: Registers Jupyter kernel for the project
15. System: "✓ Environment ready! Python 3.x with Data Science packages"
```

**Julia without kernel:**
```
1. User: Opens new_analysis.jl
2. System: Detects Julia file
3. System: Checks for Julia kernel → NOT FOUND
4. System: "Julia kernel not found. Install IJulia?"
5. User: Confirms
6. System: Shows Julia command to run:
   ```julia
   using Pkg
   Pkg.add("IJulia")
   ```
7. System: Offers to run automatically or let user run manually
8. User: Chooses automatic
9. System: Installs IJulia with progress
10. System: "✓ Julia kernel installed and initialized"
11. System: "Detected packages to install: DataFrames, Plots"
12. User: Ready to work with Julia
```

**R without kernel:**
```
1. User: Opens stats.R
2. System: Detects R file
3. System: Checks for R kernel → NOT FOUND
4. System: "R kernel not found. Install IRkernel?"
5. User: Confirms
6. System: Shows R command to run:
   ```r
   install.packages('IRkernel')
   IRkernel::installspec()
   ```
7. System: Offers to run automatically or let user run manually
8. User: Chooses automatic
9. System: Installs IRkernel with progress
10. System: "✓ R kernel installed and initialized"
11. System: "Detected packages to install: ggplot2, dplyr"
12. User: Ready to work with R
```

### 🔄 Subsequent Access Scenarios (Returning to Work)

These scenarios cover what happens when users return to files they've already worked with - the daily workflow experience.

#### Subsequent Python Access (.py or .ipynb):

**Fast Path - Everything Already Set Up:**
```
1. User: Opens project/analysis.py (previously worked on)
2. System: Detects Python file
3. System: Checks for .venv → FOUND & VALID (cached check - fast)
4. System: Checks ipykernel → FOUND (cached)
5. System: Silent initialization (no notifications unless issues)
6. System: Quick import scan → All packages present
7. User: Immediately ready to code (< 1 second total)
```

**With New Imports Added:**
```
1. User: Opens analysis.py (added new imports since last time)
2. System: Quick environment check → Valid
3. System: Scans imports → Detects NEW missing packages
4. System: "📦 New packages needed: requests, beautifulsoup4"
5. System: "Press <leader>pi to install"
6. User: One keypress to update environment
7. System: Installs only the new packages
```

**After Python/Package Updates:**
```
1. User: Opens notebook.ipynb (Python updated system-wide)
2. System: Detects Python version change
3. System: "Python version changed. Update virtual environment?"
4. User: Confirms
5. System: Recreates venv with new Python version
6. System: Reinstalls all packages from cached list
7. System: "✓ Environment updated to Python 3.12"
```

#### Subsequent Julia Access (.jl):

**Normal Return:**
```
1. User: Opens experiment.jl (worked on yesterday)
2. System: Detects Julia file
3. System: Julia kernel check → FOUND (cached)
4. System: Silent initialization
5. User: Ready to run cells immediately
```

**After Julia Package Updates:**
```
1. User: Opens analysis.jl
2. System: Detects Julia file
3. System: Initializes kernel
4. System: Detects new 'using' statements
5. System: "📦 New Julia packages: Plots, DataFrames"
6. System: Shows Julia command or auto-installs
```

#### Subsequent R Access (.R):

**Normal Return:**
```
1. User: Opens statistics.R
2. System: Detects R file
3. System: R kernel check → FOUND (cached)
4. System: Silent initialization
5. User: Ready to execute R code
```

**With New Libraries:**
```
1. User: Opens analysis.R (added library(ggplot2))
2. System: Detects new library() calls
3. System: "📦 New R packages: ggplot2"
4. System: Shows R install command or auto-installs
```

#### Subsequent Notebook Access (.ipynb):

**Quick Re-open (Most Common):**
```
1. User: Opens ml_model.ipynb (Python notebook)
2. System: Checks jupytext → Available (cached)
3. System: Reads metadata → Python (cached)
4. System: Environment check → Valid (cached)
5. System: Opens as code, initializes kernel silently
6. User: Continues where they left off (< 0.5 seconds)
```

**Switching Between Notebooks (Different Languages):**
```
1. User: Has python_analysis.ipynb open
2. User: Opens julia_sim.ipynb in split
3. System: Detects different language from metadata
4. System: Keeps Python kernel for first notebook
5. System: Initializes Julia kernel for second
6. System: Both kernels run independently
7. User: Can execute cells in both languages
```

**Shared Project, Different Machine (via git):**
```
1. User: Clones project with notebooks
2. User: Opens analysis.ipynb
3. System: Detects .ipynb → Checks jupytext
4. System: Reads metadata → Python
5. System: No .venv found (different machine)
6. System: "No environment found. Create from requirements.txt?"
7. User: Confirms
8. System: Creates .venv matching original setup
9. System: "✓ Environment recreated from requirements"
```

### 🚀 Performance Optimizations for Subsequent Access

#### Caching Strategy:
```lua
-- Cache TTLs (Time To Live)
cache_config = {
    venv_check = 30,        -- 30 seconds
    kernel_list = 60,       -- 1 minute
    package_list = 300,     -- 5 minutes
    jupytext_check = 3600,  -- 1 hour (rarely changes)
    metadata_parse = 120,   -- 2 minutes per file
}
```

#### Smart Background Checks:
```
1. On file open → Use cached data for instant readiness
2. In background → Refresh caches if expired
3. If changes detected → Show non-blocking notification
4. User continues working → Can address changes when convenient
```

#### Instant Ready States:
- **Goal**: < 0.5 seconds from file open to ready
- **Method**: Cache everything possible
- **Updates**: Handle asynchronously in background
- **Notifications**: Only show if action needed

### 📊 Subsequent Access Patterns

#### Daily Developer Workflow:
```
Morning:
1. Open main project file → Instant (cached)
2. Environment valid → Silent success
3. Start coding immediately

Adding dependency:
1. Add new import in code
2. Save file
3. System detects on save → Shows missing package
4. One-key install
5. Continue coding

End of day:
1. All environments stay ready
2. Kernels persist in memory
3. Tomorrow's startup will be instant
```

#### Data Scientist Workflow:
```
Notebook iteration:
1. Open notebook → Instant (everything cached)
2. Run cells → Kernel already initialized
3. Modify code → Real-time execution
4. Add new import → Inline notification
5. Install package → No restart needed
6. Continue analysis seamlessly
```

#### Multi-language Researcher:
```
Language switching:
1. Python notebook open → Python kernel active
2. Open Julia file → Julia kernel initializes
3. Open R script → R kernel initializes  
4. All three kernels running simultaneously
5. Switch between files → Instant (all ready)
6. Share data via files → Each language reads/writes
```

#### Scenario C: Mixed Environment States
**Context:** Some parts exist, others don't

**Has venv but no Jupyter support:**
```
1. User: Opens notebook.ipynb
2. System: Detects notebook (Python from metadata)
3. System: Finds .venv → Valid Python environment
4. System: Checks for ipykernel → NOT FOUND
5. System: "Installing Jupyter support in existing environment..."
6. System: Installs: ipykernel, jupyter_client, jupytext
7. System: Registers kernel with project name
8. System: "✓ Jupyter support added to .venv"
9. System: Opens notebook in readable format
10. User: Can execute cells immediately
```

**Has global kernel but wants project-specific:**
```
1. User: Opens ml_project/train.py
2. System: Detects Python file
3. System: No local .venv found
4. System: Finds global Python kernel
5. System: "Found global kernel. Create project-specific environment?"
6. User: Confirms
7. System: Creates .venv for isolation
8. System: Copies/installs packages from requirements.txt if exists
9. System: Registers project-specific kernel
10. System: "✓ Project environment created, separate from global"
```

### Scenario 1: New Data Science Project
```
1. User: mkdir my_analysis && cd my_analysis && nvim
2. User: :PyworksSetup
3. System: Shows menu [Data Science, Web, General, Custom]
4. User: Selects "Data Science"
5. System: Creates .venv, installs packages, configures kernel
6. User: :PyworksNewNotebook exploration.ipynb
7. System: Creates notebook, opens in readable format
8. User: Writes import pandas as pd
9. System: Detects pandas is installed, ready to go
10. User: Executes cells, sees output
```

### Scenario 2: Opening Colleague's Notebook
```
1. User: nvim colleague_analysis.ipynb
2. System: Detects .ipynb, checks jupytext
3. System: Opens as Python code (not JSON)
4. System: Detects missing packages from imports
5. System: "Missing: scipy, seaborn. Press <leader>pi to install"
6. User: Presses <leader>pi
7. System: Installs packages with progress
8. System: "Environment ready!"
9. User: Runs cells successfully
```

### Scenario 3: Multi-Language Research Project
```
1. User: Opens preprocessing.py
2. System: Initializes Python kernel
3. User: Opens analysis.jl in split
4. System: Detects Julia, initializes Julia kernel
5. User: Opens visualization.R in another split
6. System: Detects R, initializes R kernel
7. User: Can execute code in all three languages
8. System: Maintains separate kernel states
```

## 🧠 Smart Detection & Decision Trees

### Environment Detection Logic

#### For Python Files:
```
Open .py/.ipynb
    ↓
Check for .venv/ in project root
    ├─ Found → Validate Python version
    │   ├─ Valid → Use it
    │   └─ Invalid → Offer to recreate
    └─ Not Found → Check for global venv
        ├─ Found → Offer: Use global or create local?
        └─ Not Found → Prompt to create .venv
```

#### For Julia Files:
```
Open .jl
    ↓
Check for Julia installation
    ├─ Found → Check for IJulia kernel
    │   ├─ Found → Initialize and use
    │   └─ Not Found → Prompt to install IJulia
    └─ Not Found → Show Julia installation guide
```

#### For R Files:
```
Open .R
    ↓
Check for R installation
    ├─ Found → Check for IRkernel
    │   ├─ Found → Initialize and use
    │   └─ Not Found → Prompt to install IRkernel
    └─ Not Found → Show R installation guide
```

### Smart Defaults Based on Context

#### File Type Detection:

**For .ipynb files (special handling):**
```lua
function detect_notebook_language(filepath)
    -- 1. Read the .ipynb JSON
    -- 2. Extract metadata.kernelspec.language
    -- 3. Fallback chain:
    --    a. Check metadata.language_info.name
    --    b. Check metadata.kernelspec.name (parse for clues)
    --    c. Scan first code cell for syntax hints
    --    d. Prompt user to select language
    
    if metadata.kernelspec.language then
        return metadata.kernelspec.language  -- "python", "julia", "R"
    elseif metadata.language_info.name then
        return metadata.language_info.name
    elseif metadata.kernelspec.name:match("python") then
        return "python"
    elseif metadata.kernelspec.name:match("julia") then
        return "julia"
    elseif metadata.kernelspec.name:match("ir") then
        return "R"
    else
        -- Scan first code cell
        first_cell = get_first_code_cell()
        if first_cell:match("import%s") or first_cell:match("from%s") then
            return "python"
        elseif first_cell:match("using%s") or first_cell:match("Julia") then
            return "julia"
        elseif first_cell:match("library%(") or first_cell:match("<%-") then
            return "R"
        else
            -- Default to Python (most common)
            vim.notify("No language detected in notebook, defaulting to Python", vim.log.levels.INFO)
            return "python"
        end
    end
end
```

**For regular files:**
- `.py` → Python environment
- `.jl` → Julia environment
- `.R` → R environment
- `# %%` in .py → Jupyter cell mode (Python)

#### Package Manager Selection (Python):
```
if command_exists("uv") then
    use_uv()  -- 10-100x faster
elseif in_venv() then
    use_pip()  -- Use venv's pip
else
    use_system_pip()  -- Fallback
end
```

#### Template Auto-Selection:
```
if has_file("requirements.txt") then
    parse_and_categorize_packages()
    suggest_appropriate_template()
elseif has_file("pyproject.toml") then
    detect_project_type_from_toml()
elseif has_imports("pandas", "numpy") then
    suggest_data_science_template()
elseif has_imports("fastapi", "flask", "django") then
    suggest_web_template()
else
    show_all_templates()
end
```

## 📋 Edge Cases & Error Handling

### Edge Case 1: Python 3.12+ with TensorFlow
**Scenario:** User tries to install TensorFlow on Python 3.12+  
**Solution:** Detect incompatibility, suggest PyTorch/JAX, allow skip

### Edge Case 2: Corrupted Virtual Environment
**Scenario:** Venv exists but is broken  
**Solution:** Detect corruption, offer to recreate, preserve package list

### Edge Case 3: No Internet Connection
**Scenario:** User tries to install packages offline  
**Solution:** Check connectivity, suggest offline alternatives, cache packages

### Edge Case 4: Conflicting Kernels
**Scenario:** Multiple kernels with same name  
**Solution:** Show disambiguated list, allow selection, option to remove duplicates

### Edge Case 5: Large Notebook Files
**Scenario:** Opening 100MB+ notebook  
**Solution:** Stream conversion, show progress, option to preview first N cells

## 🎨 UI/UX Principles

### 1. Progressive Disclosure
- Start with minimal UI, reveal options as needed
- Don't overwhelm new users with all features at once
- Provide sensible defaults that work for 80% of cases

### 2. Fail Gracefully
- Every error should have a suggested fix
- Never leave user in broken state
- Provide rollback/recovery options

### 3. Visual Feedback
- Show progress for long operations
- Use consistent icons/colors for status
- Animate transitions (terminal permitting)

### 4. Predictable Behavior
- Same file type = same workflow every time
- Consistent keybindings across languages
- Remember user preferences per project

### 5. Zero Configuration
- Everything should work out of the box
- Smart defaults based on context
- Optional configuration for power users

## 🚦 Success Metrics

### Quantitative:
- Time from file open to first execution < 5 seconds
- Package installation success rate > 95%
- Kernel initialization success rate > 99%
- Zero configuration required for 80% of use cases

### Qualitative:
- Users report "it just works"
- Reduced friction compared to VSCode/JupyterLab
- Positive feedback on auto-detection accuracy
- Users recommend to colleagues

## 🔮 Future Enhancements

### Phase 2:
- Remote kernel support (SSH, Docker, Cloud)
- Variable inspector/explorer
- Inline plot previews in code
- Collaborative editing support

### Phase 3:
- AI-powered package suggestions
- Automated environment optimization
- Cross-language data sharing
- Notebook version control integration

### Phase 4:
- Cloud environment sync
- Team environment templates
- Performance profiling integration
- GPU/TPU resource management

## 📝 Implementation Priority

### P0 (Critical):
1. First-time notebook display (not JSON)
2. Auto-environment detection
3. Package missing detection
4. One-click package installation

### P1 (Important):
1. Multi-language kernel support
2. Project templates
3. Environment health monitoring
4. Better error messages

### P2 (Nice to Have):
1. Remote kernels
2. Variable inspector
3. Performance optimizations
4. Advanced customization

## 🧪 Testing Scenarios

### Test 1: Fresh Install
- No Python environment
- No jupytext installed
- Open .ipynb file
- Verify full setup flow works

### Test 2: Existing Environment
- Has venv with some packages
- Open Python file with new imports
- Verify missing package detection
- Verify installation preserves existing

### Test 3: Language Switching
- Open Python file (kernel initializes)
- Open Julia file (new kernel)
- Execute code in both
- Verify independent execution

### Test 4: Error Recovery
- Corrupt venv
- Missing kernel
- Network failure during install
- Verify graceful handling

## 📊 User Feedback Integration

### Feedback Channels:
- GitHub Issues
- Discord community
- User surveys
- Analytics (opt-in)

### Iteration Process:
1. Collect feedback weekly
2. Prioritize by impact/effort
3. Release improvements bi-weekly
4. Measure success metrics

## 📌 Key Behavioral Differences

### Notification Philosophy:

**First-Time Access:**
- Verbose: Show what's happening
- Educational: Explain what's being set up
- Interactive: Prompt for decisions
- Progress indicators: Show installation status

**Subsequent Access:**
- Silent when everything works
- Notify only for actionable items
- No prompts for known configurations
- Instant readiness is the priority

### Decision Making:

**First-Time:**
```
"No environment detected. Create one?"
→ Requires user decision
```

**Subsequent:**
```
Environment exists → Use it silently
Environment missing → Check if it moved/renamed first
```

### Package Management:

**First-Time:**
```
"📦 Missing packages: numpy, pandas, matplotlib"
"Would you like to install them? [Y/n]"
```

**Subsequent:**
```
"📦 New package detected: requests"
"Press <leader>pi to install"
→ Non-blocking, user continues working
```

## 🎯 North Star Vision

The ultimate goal is for users to never think about environment setup. They open a file, and everything just works. The environment is ready, packages are installed, kernels are configured, and they can focus entirely on their code and analysis.

When someone says "How do I set up Python in Neovim?", the answer should simply be: "Install pyworks.nvim and open your file."