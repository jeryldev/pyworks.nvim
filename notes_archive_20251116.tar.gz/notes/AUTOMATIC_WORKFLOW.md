# 🚀 Pyworks.nvim - Fully Automatic Workflow

## Zero Manual Steps Required!

When you open ANY supported file, everything happens automatically:

### What Happens Automatically:

1. **Environment Setup** (by Pyworks)
   - Creates virtual environment (.venv for Python)
   - Installs essential packages
   - Detects missing packages from imports

2. **Molten Auto-Initialization** (FULLY AUTOMATIC!)
   - Happens 200ms after file open
   - Detects file type automatically
   - Initializes appropriate kernel:
     - Python (.py/.ipynb) → `python3` kernel
     - Julia (.jl/.ipynb) → `julia` kernel  
     - R (.R/.ipynb) → `ir` kernel
   - Shows clear notification: "✅ Molten ready with [kernel] kernel - Use <leader>jl to run code"

3. **Ready to Execute**
   - Use keymaps immediately
   - NO manual initialization EVER needed
   - NO prompts or interruptions

## The Complete Automatic Flow

### Python File (.py)
```
Open test.py
  ↓
Pyworks: Creates .venv (if needed)
  ↓
Pyworks: Installs pynvim, ipykernel, jupyter_client, jupytext
  ↓
Pyworks: Detects imports (numpy, pandas, etc.)
  ↓
Pyworks: Shows missing packages (only if any)
  ↓
Molten: AUTO-INITIALIZES python3 kernel (200ms)
  ↓
Shows: "✅ Molten ready with python3 kernel"
  ↓
READY! Use <leader>jl, <leader>jv, <leader>jr immediately!
```

### Julia File (.jl)
```
Open test.jl
  ↓
Pyworks: Checks Julia installation
  ↓
Pyworks: Prompts for IJulia (if needed)
  ↓
Pyworks: Detects using/import statements
  ↓
Pyworks: Shows missing packages (only if any)
  ↓
Molten: AUTO-INITIALIZES julia kernel (200ms)
  ↓
Shows: "✅ Molten ready with julia kernel"
  ↓
READY! Use <leader>jl, <leader>jv, <leader>jr immediately!
```

### R File (.R)
```
Open test.R
  ↓
Pyworks: Checks R installation
  ↓
Pyworks: Prompts for IRkernel (if needed)
  ↓
Pyworks: Detects library() calls
  ↓
Pyworks: Shows missing packages (only if any)
  ↓
Molten: AUTO-INITIALIZES ir kernel (200ms)
  ↓
Shows: "✅ Molten ready with ir kernel"
  ↓
READY! Use <leader>jl, <leader>jv, <leader>jr immediately!
```

### Python Notebook (.ipynb)
```
Open notebook.ipynb
  ↓
Pyworks: Ensures jupytext is installed (BufReadPre)
  ↓
Pyworks: Creates .venv if needed
  ↓
Jupytext.nvim: Converts to readable format
  ↓
Pyworks: Detects Python from metadata
  ↓
Pyworks: Scans all cells for imports
  ↓
Pyworks: Shows missing packages (only if any)
  ↓
Molten: AUTO-INITIALIZES python3 kernel (200ms)
  ↓
Shows: "✅ Molten ready with python3 kernel"
  ↓
READY! Navigate cells with ]j/[j, execute with <leader>jv
```

### Julia Notebook (.ipynb)
```
Open julia_notebook.ipynb
  ↓
Pyworks: Ensures jupytext is installed
  ↓
Jupytext.nvim: Converts to readable format
  ↓
Pyworks: Detects Julia from metadata
  ↓
Pyworks: Ensures IJulia kernel available
  ↓
Pyworks: Scans cells for using/import
  ↓
Pyworks: Shows missing packages (only if any)
  ↓
Molten: AUTO-INITIALIZES julia kernel (200ms)
  ↓
Shows: "✅ Molten ready with julia kernel"
  ↓
READY! Navigate cells with ]j/[j, execute with <leader>jv
```

### R Notebook (.ipynb)
```
Open r_notebook.ipynb
  ↓
Pyworks: Ensures jupytext is installed
  ↓
Jupytext.nvim: Converts to readable format
  ↓
Pyworks: Detects R from metadata
  ↓
Pyworks: Ensures IRkernel available
  ↓
Pyworks: Scans cells for library() calls
  ↓
Pyworks: Shows missing packages (only if any)
  ↓
Molten: AUTO-INITIALIZES ir kernel (200ms)
  ↓
Shows: "✅ Molten ready with ir kernel"
  ↓
READY! Navigate cells with ]j/[j, execute with <leader>jv
```

## No Manual Steps!

You DON'T need to:
- ❌ Run :MoltenInit manually
- ❌ Select kernels manually  
- ❌ Create environments manually
- ❌ Install packages manually (except with <leader>pi)
- ❌ Configure anything

Everything is automatic!

## Timeline

| Time | What Happens | Visible to User |
|------|-------------|-----------------|
| 0s | File opened | File content shown |
| 0.1s | Pyworks starts environment check | Silent (unless missing packages) |
| 0.2s | Molten auto-initializes | "Setting up [language] kernel..." |
| 0.3s | Kernel ready | "✅ Molten ready with [kernel] kernel" |
| 0.4s | **READY TO USE** | Just start coding! |

## Keymaps Available Immediately

Once Molten initializes (0.2 seconds after file open):

| Keymap | Action | Works Instantly | Notes |
|--------|--------|-----------------|-------|
| `<leader>jl` | Run current line | ✅ | Moves to next line after execution |
| `<leader>jv` | Run visual selection | ✅ | Evaluates the visually highlighted selection |
| `<leader>jr` | Select cell/file | ✅ | Visually highlights current cell or entire file |
| `<leader>jc` | Re-run cell | ✅ | Re-evaluates current cell |
| `<leader>jd` | Delete output | ✅ | Removes cell output |
| `<leader>jo` | Toggle output | ✅ | Show/hide output window |
| `]j` | Next cell | ✅ | Jump to next cell marker |
| `[j` | Previous cell | ✅ | Jump to previous cell marker |

## Second Time Opening Same File

```
Open test.py (again)
  ↓
Everything cached, instant ready
  ↓
Molten: Already initialized
  ↓
INSTANT! Start executing code
```

## Why the 200ms Delay?

The Molten initialization waits 200ms to ensure:
- Buffer is fully loaded and settled
- File type detection is complete
- Environment setup has started

This minimal delay prevents errors while keeping the experience fast.

## Troubleshooting

If Molten doesn't auto-initialize:
1. Check `:messages` for errors
2. Verify kernel is installed:
   - Python: `ipykernel` (auto-installed)
   - Julia: `IJulia` (prompted)
   - R: `IRkernel` (prompted)
3. Manually initialize with `<leader>mi` as fallback

## Summary

**Just open a file and start coding!**
- Pyworks handles environment
- Molten initializes automatically
- Keymaps work immediately
- Same workflow for all 6 scenarios

The true zero-configuration experience!