# %% Configure matplotlib for inline display PROPERLY
import matplotlib
# Set backend BEFORE importing pyplot
matplotlib.use('module://matplotlib_inline.backend_inline')
import matplotlib.pyplot as plt
import numpy as np

# Alternative: If the above doesn't work, try:
# matplotlib.use('Agg')

# %% Create a test plot
x = np.linspace(0, 10, 100)
y = np.sin(x)

plt.figure(figsize=(8, 6))
plt.plot(x, y, 'b-', linewidth=2)
plt.title('Inline Plot Test - No External Window')
plt.xlabel('X axis')
plt.ylabel('Y axis')
plt.grid(True)

# Just create the plot, don't call plt.show()
# Molten will capture it automatically
plt.gcf()

# %% Test with multiple plots
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
ax1.plot(x, np.sin(x))
ax1.set_title('Sin(x)')
ax2.plot(x, np.cos(x))
ax2.set_title('Cos(x)')
plt.tight_layout()
# Again, no plt.show() needed