# %% Configure IPython for inline display
from IPython import get_ipython
get_ipython().run_line_magic('matplotlib', 'inline')

# %% Now create plots - they should NOT open external windows
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 10, 100)
y = np.sin(x)

plt.figure(figsize=(8, 6))
plt.plot(x, y, 'b-', linewidth=2)
plt.title('This should display inline, not in external window')
plt.xlabel('X axis')
plt.ylabel('Y axis')
plt.grid(True)

# Don't use plt.show() - just display the figure
# The plot should appear in Molten output only